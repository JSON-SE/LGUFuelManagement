
<?php $__env->startSection('content'); ?>

    <section id="body-content" class="">
        <div class="container-fluid px-lg-5 px-md-4 pb-5 pt-lg-3">
            <div class="row pt-4">
                <div class="col-12">
                    <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='white'/%3E%3C/svg%3E&#34;);"
                        aria-label="breadcrumb">
                        <ol class="breadcrumb mb-2">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Add Extra price</li>
                        </ol>
                    </nav>
                </div>
            </div>
            <div class="row pb-4">
                <div class="col-sm-6 text-white my-auto">
                    <h3 class="mb-0">Extra price</h3>
                </div>
            </div>

            <div class="bg-white rounded page-height mt-3 shadow">
                <?php echo $__env->make('partial.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="p-4 pb-5">
                    <ul class="nav nav-tabs product-management-tab __tabslide" id="myTab" role="tablist">

                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="Shipping-tab" data-bs-toggle="tab"
                                data-bs-target="#Shipping" type="button" role="tab" aria-controls="Shipping"
                                aria-selected="true">Shipping</button>
                        </li>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="Handling-tab" data-bs-toggle="tab" data-bs-target="#Handling"
                                type="button" role="tab" aria-controls="Handling" aria-selected="false">Handling</button>
                        </li>

                    </ul>

                    <div class="tab-content" id="myTabContent">

                        <div class="tab-pane fade show active" id="Shipping" role="tabpanel" aria-labelledby="Shipping-tab">
                            <div class="pt-2">
                                <form action="<?php echo e(url('/admin/extra-setting-shipping-price')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('post'); ?>
                                    <input type="hidden" name="shipping_price_id" value="<?php echo e($shipping_price->id ?? ''); ?>">
                                    <div class="row">
                                        <div class="col-lg-4 col-md-4">
                                            <div class="form-floating mt-3">
                                                <input type="number" class="form-control" name="min_width" id="min_width"
                                                    value="<?php echo e($shipping_price->min_width??''); ?>" placeholder="Minimum width"
                                                    autocomplete="off" min="94" required>
                                                <label for="min_width">Minimum width <span
                                                        class="text-primary"></span></label>
                                            </div>
                                        </div>
                                     
                                        <div class="col-lg-4 col-md-4">
                                            <div class="form-floating mt-3">
                                                <input type="text" class="form-control" required name="amount" id="amount"
                                                    value="<?php echo e($shipping_price->amount?? ''); ?>" placeholder="Amount">
                                                <label for="amount">Amount<span class="text-primary">*</span></label>
                                            </div>
                                        </div>

                                        <div class="col-lg-4 col-md-6 mt-3">
                                            <button type="submit" class="btn btn-primary">Update</button>
                                        </div>
                                    </div>

                                </form>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="Handling" role="tabpanel" aria-labelledby="Handling-tab">
                           
                            <div class="pt-2">
                                <form action="<?php echo e(url('/admin/extra-setting-handling-price')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('post'); ?>
                                   
                                    <div class="row align-items-end">
                                        
                                        <div class="col-12" id="option-price-Handling">
                                            <?php if($handlingPrice->count() > 0): ?>
                                            <?php $__currentLoopData = $handlingPrice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $handling): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="row gx-2 option-price pb-3 option-Handling">
                                                <div class="col-md-3">
                                                    <div class="form-floating">
                                                        <input type="text" class="form-control min_range" id="min_range" value="<?php echo e($handling->min_range); ?>"
                                                               placeholder="Width" name="min_range[]" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
                                                        <label for="">Min Range</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-floating">
                                                        <input type="text" class="form-control range"
                                                               placeholder="Width" name="max_range[]" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"  value="<?php echo e($handling->max_range); ?>" required>
                                                        <label for="">Max Range</label>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="form-floating">
                                                        <input type="text" class="form-control" id="" value="<?php echo e($handling->amount); ?>"
                                                               placeholder="Price" name="price[]" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"  required>
                                                        <label for="">Price</label>
                                                    </div>
                                                </div>
                                                <?php if($key == 0): ?>
                                                <div class="col-md-3">
                                                    <a href="javascript:void(0)"
                                                       class="btn btn-primary btn-sm pe-3 h-100 add-option-Handling ms-auto">
                                                       <span class="d-flex h-100 align-items-center">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                                                fill="currentColor" class="bi bi-plus" viewBox="0 0 16 16">
                                                                <path
                                                                    d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z">
                                                                </path>
                                                            </svg>
                                                            <span class="d-none d-md-block">Add more</span>
                                                        </span>
                                                    </a>
                                                   
                                                </div>
                                                <?php else: ?>
                                                <div class="col-md-3">
                                                    <a href="javascript:void(0)"
                                                       class="btn btn-secondary btn-sm pe-3 h-100 remove-option-price ms-auto">
                                                       <span class="d-flex h-100 align-items-center">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-dash" viewBox="0 0 16 16">
                                                            <path d="M4 8a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7A.5.5 0 0 1 4 8z"/>
                                                          </svg>
                                                            <span class="d-none d-md-block">Remove</span>
                                                        </span>
                                                    </a>
                                                   
                                                </div>
                                                <?php endif; ?>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                              <div class="row gx-2 option-price pb-3 option-Handling">
                                                <div class="col-md-3">
                                                    <div class="form-floating">
                                                        <input type="text" class="form-control range" 
                                                               placeholder="Width" name="min_range[]" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
                                                        <label for="">Min Range</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-floating">
                                                        <input type="text" class="form-control range"
                                                               placeholder="Width" name="max_range[]" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"   required>
                                                        <label for="">Max Range</label>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3">
                                                    <div class="form-floating">
                                                        <input type="text" class="form-control" id="" 
                                                               placeholder="Price" name="price[]" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"  required>
                                                        <label for="">Price</label>
                                                    </div>
                                                </div>
                                               
                                                <div class="col-md-3">
                                                    <a href="javascript:void(0)"
                                                       class="btn btn-primary btn-sm pe-3 h-100 add-option-Handling ms-auto">
                                                       <span class="d-flex h-100 align-items-center">
                                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                                                fill="currentColor" class="bi bi-plus" viewBox="0 0 16 16">
                                                                <path
                                                                    d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z">
                                                                </path>
                                                            </svg>
                                                            <span class="d-none d-md-block">Add more</span>
                                                        </span>
                                                    </a>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                        
                                        

                                        <div class="col-lg-12 col-md-6 mt-3">
                                            <button type="submit" class="btn btn-primary">Update</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
</section>

    <?php $__env->startPush('js'); ?>
        <script type="text/javascript">

        $(document).ready(function (){

            $(document).on('click', '.__tabslide li .nav-link', function(e) {
                e.preventDefault();
                var newurl = window.location.protocol + "//" + window.location.host + window.location.pathname + '?tab=' + this.id;
                window.history.pushState({ path: newurl }, '', newurl);
            });

            $(window).on('load', function() {
                var queryString = window.location.search;
                var urlParams = new URLSearchParams(queryString);

                var id = urlParams.get('tab')
             
                if(urlParams.has('tab')== true){
                    // $('.product-management-tab ')
                    $('.tab-content .tab-pane').removeClass('active show');
                    $('.__tabslide li button').removeClass('active');
                    $(".tab-content").find("[aria-labelledby="+id+"]").addClass('active show');
                    $('.__tabslide li').find('#'+id).addClass('active');
                    console.log(id);
                }
            });

            $(document).on("click", ".add-option-Handling", function () {
                $("#option-price-Handling").append(html())
            });

            $(document).on('click', '.remove-option-price', function(){
                $(this).parents('.option-Handling').remove();
            });

            function html() {
                    return `<div class="row gx-2 option-price pb-3 option-Handling">
                            <div class="col-md-3">
                                <div class="form-floating">
                                    <input type="text" class="form-control min_range" value=""
                                           placeholder="Width" name="min_range[]" oninput="this.value = this.value.replace(/[^0-9.]/g, '')"  required>
                                    <label for="">Min Range</label>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-floating">
                                    <input type="text" class="form-control range" 
                                           placeholder="Width" name="max_range[]" oninput="this.value = this.value.replace(/[^0-9.]/g, '')"  required>
                                    <label for="">Max Range</label>
                                </div>
                            </div>
                            
                            <div class="col-md-3">
                                <div class="form-floating">
                                    <input type="text" class="form-control"
                                           placeholder="Price" name="price[]" oninput="this.value = this.value.replace(/[^0-9.]/g, '')" required>
                                    <label for="">Price</label>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <a href="javascript:void(0)"
                                   class="btn btn-secondary btn-sm pe-3 h-100 remove-option-price ms-auto">
                                    <span class="d-flex h-100 align-items-center">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-dash" viewBox="0 0 16 16">
  <path d="M4 8a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7A.5.5 0 0 1 4 8z"/>
</svg>
                                        <span class="d-none d-md-block">Remove</span>
                                    </span>
                                </a>
                            </div>
                        </div>`;
        }
          $(document).on('change','.range', function() {
                const optionRow = $(this).closest('.option-Handling');
                const optionMinValue = optionRow.find('.min_range').val();
                const optionMaxValue = $(this).val();
                const optionMinValueNum = parseInt(optionMinValue);
                const optionMaxValueNum = parseInt(optionMaxValue);

                if (optionMaxValueNum <= optionMinValueNum  ) {
                    alert("Max range is grater than min rage");
                    $(this).val('');
                    $(this).focus();
                }
            })

            $(document).on('change','.min_range', function() {
                const optionRow = $(this).closest('.option-Handling');
                const previousRowMaxField = optionRow.prev().find('.range');
                const previousRowMaxFieldValue = previousRowMaxField.length > 0 ? parseInt(previousRowMaxField.val()) : 0;
                const currentMinFieldValue = parseInt($(this).val());

                const optionMaxValue = optionRow.find('.range').val();
                const optionMaxValueNum = parseInt(optionMaxValue);

                if(currentMinFieldValue!==NaN && currentMinFieldValue <= previousRowMaxFieldValue){
                    alert(`Min range value has to be greater than last max range value i.e. ${previousRowMaxFieldValue}`);
                    $(this).val('');
                    $(this).focus();
                    return
                } else if(currentMinFieldValue > optionMaxValueNum){
                    alert(`Min range value cann't be greater than max range value`);
                    $(this).val('');
                    $(this).focus();
                    return
                }

            })
        });
        </script>


    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Backend.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\heyblinds\resources\views/admin/extra/extra.blade.php ENDPATH**/ ?>