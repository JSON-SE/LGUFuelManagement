<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Abandoned Savercart</title>
</head>
<body>
    <p><b>Cart ID:</b> <?php echo e($cart_id ?? ''); ?></p>
    <p><b>First Name:</b> <?php echo e($first_name ?? ''); ?></p>
    <p><b>Last Name: </b><?php echo e($last_name ?? ''); ?></p>
    <p><b>Email:</b> <?php echo e($email ?? ''); ?></p>
    <p><b>Cart Amount:</b> $<?php echo e(number_format($cart_amount,2) ?? ''); ?></p><br/>

    
</body>
</html><?php /**PATH D:\Project\heyblinds\resources\views/emails/abandoned-savecart.blade.php ENDPATH**/ ?>