
<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('admin.promo.update', $promo->id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <section id="body-content" class="">
            <div class="container-fluid px-lg-5 px-md-4 pb-5 pt-lg-3">
                <div class="row pt-4">
                    <div class="col-12">
                        <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='white'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
                            <ol class="breadcrumb mb-2">
                                <li class="breadcrumb-item"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Update Promo</li>
                            </ol>
                        </nav>
                    </div>
                </div>
                <div class="row pb-4">
                    <div class="col-sm-6 text-white my-auto">
                        <h3 class="mb-0">Edit: <?php echo e($promo->name ?? ""); ?></h3>
                    </div>
                    <div class="col-sm-6 pt-3 pt-lg-0 my-auto d-flex justify-content-sm-end">
                        <a href="<?php echo e(route('admin.promo.index')); ?>" class="btn btn-light">All Promos</a>
                        <a href="<?php echo e(route('admin.promo.create')); ?>" class="btn btn-primary d-flex align-items-center ms-2">
                            <span class="d-none d-md-block">Create new Promo</span>
                        </a>
                    </div>

                </div>

                <div class="bg-white rounded page-height mt-3 shadow">
                    <?php echo $__env->make('partial.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="p-4">
                        <div class="row gx-2">
                            <div class="col-lg-3">
                                <div class="form-floating mt-3">
                                    <input type="text" class="form-control" name="name" id="name" value="<?php echo e($promo->name); ?>" placeholder="Coupon Name" >
                                    <label for="name">Promo Title<span class="text-primary">*</span></label>
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class="form-floating mt-3">
                                    <select name="type" id="type" class="form-select" >
                                        <option value="">Select Type</option>
                                        <option value="percentage" <?php echo e($promo->discount_type === "percentage" ? "selected" : ""); ?>>Percentage</option>
                                        <option value="flat" <?php echo e($promo->discount_type === "flat" ? "selected" : ""); ?>>Fixed Amount</option>
                                        <option value="free_shipping" <?php echo e($promo->discount_type === "free_shipping" ? "selected" : ""); ?>>Free Shipping</option>
                                    </select>
                                    <label for="type">Promo Type<span class="text-primary">*</span></label>
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class="input-group mt-3">
                                    <span class="input-group-text">%</span>
                                    <input type="text" class="form-control" id="amountField" name="amount" value="<?php echo e($promo->amount); ?>" aria-label="Amount (to the nearest dollar)" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="2" >
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class="input-group mt-3">
                                    <span class="input-group-text">%</span>
                                    <input type="text" class="form-control" id="extra_amount_promo" name="extra_amount" value="<?php echo e($promo->extra_amount); ?>" aria-label="Amount (to the nearest dollar)"  oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" placeholder="Extra discount" autocomplete="off" maxlength="2" >
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="form-floating mt-3">
                                    <input type="datetime-local" class="form-control" id="start_date" name="start_date" step="1"
                                           value="<?php echo e(date("Y-m-d", strtotime($promo->start_date))."T".date("H:i:s", strtotime($promo->start_date))); ?>"
                                           placeholder="Start Date">
                                    <label for="start_date">Start Date<span class="text-primary">*</span></label>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="form-floating mt-3">
                                    <input type="datetime-local" class="form-control" id="end_date" name="end_date" step="1"
                                           value="<?php echo e(date("Y-m-d", strtotime($promo->end_date))."T".date("H:i:s", strtotime($promo->end_date))); ?>"
                                           placeholder="End Date" min="<?php echo e(date("Y-m-d")."T".date("H:i:s")); ?>">
                                    <label for="end_date">End Date<span class="text-primary">*</span></label>
                                </div>
                            </div>
                        
                            <div class="col-md-4">
                                <div class="mt-3">
                                    <input class="form-control form-control-lg" type="file" id="formFile" name="banner" accept="image/*">
                                   
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-floating mt-3">
                                    
                                     <input type="text" class="form-control" name="banner_link" id="banner_link" value="<?php echo e($helpers->bannerUrl($promo->id)); ?>" placeholder="Banner Link" >
                                    <label for="banner_link">Banner Link</label>
                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="form-floating mt-3">
                                    <input type="text" class="form-control" name="ticker" id="ticker" value="<?php echo e($promo->ticker); ?>" placeholder="Message Bar Text" >
                                    <label for="ticker">Message Bar Text</label>
                                </div>
                            </div>
                            <div class="col">
                                <div class="check-box d-inline-block mt-4">
                                    <input type="checkbox" id="is_active" name="is_active" value="1" <?php echo e($promo->is_active == true ? "checked" : ""); ?> >
                                    <label for="is_active">Active</label>
                                </div>
                            </div>
                            <div class="col">
                                <div class="check-box d-inline-block mt-4">
                                    <input type="checkbox" id="hide_timer" name="hide_timer" value="1" <?php echo e($promo->hide_timer == true ? "checked" : ""); ?> >
                                    <label for="hide_timer">Hide Timer</label>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row gx-2 mt-3">
                            <div class="col-md-6">
                                <div class="form-floating mt-3">
                                        <input type="text" class="form-control" name="mob_text_bar" id="mob_text_bar" value="<?php echo e($promo->mob_text_bar); ?>" placeholder="Message Bar Text" >
                                        <label for="ticker">Message Bar  for mobile </label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating mt-3">
                                        <input type="text" class="form-control" name="coupon_text_box" id="coupon_text_box" value="<?php echo e($promo->coupon_text_box ?? ' '); ?>" placeholder="Enter coupon box message"/>
                                        <label for="ticker">Enter coupon box message </label>
                                </div>
                            </div>
                    </div>

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="mt-3">
                                    <label for="content" class="mb-2 fw-bold">Detail Promo Description </label>
                                    <textarea id="content" name="content" class="summernote"><?php echo e($promo->content); ?></textarea>
                                </div>
                            </div>
                        </div>
                        <?php if($sliders->count() > 0): ?>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="mt-3">
                                    <label for="content" class="mb-2 fw-bold">Slider reorder</label>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-hover colourtable">
                                        <tbody class="ui-sortable sortable">
                                            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr id="item-<?php echo e($slider->id); ?>">
                                                <td>#</td>
                                                <td>Slider <?php echo e($key+1); ?> <a href="<?php echo e($helpers->getSliderImage($slider->media_id)); ?>" target="_blank" class="ml-3">Show image</a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        <div class="col-md-12 mt-5 text-end">
                            <button type="submit" class="btn btn-primary">Update Promo</button>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script>
        jQuery(function($) {
            $( ".sortable" ).sortable({
                stop: function (event, ui) {
                    var data = $(this).sortable('serialize');
                    $.ajax({
                        data: {
                            "data" : data,
                            "where" : "id",
                            "t" : "sliders",
                        },
                        type: 'POST',
                        url: '<?php echo e(route('global.sort')); ?>'

                    });
                }
            });
        })
        function isNumber (o) {
            return ! isNaN (o-0);
        }

        $(document).on('keyup', "#amountField", function(e){
            let txtVal = $(this).val();
            if(isNumber(txtVal) && txtVal.length>3)
            {
                $(this).val(txtVal.substring(0,3) )
            }
        });
        jQuery(function ($) {
            if ($("#type").val() === ""){
                $(".input-group-text").text("");
                $("input[name='amount']").css('text-indent', '-1000px').prop('disabled', true);
                $("input[name='extra_amount']").css('text-indent', '-1000px').prop('disabled', true);
            }
            $(document).on('change', "#type", function () {
                let $this = $(this);
                if ($this.val() === "percentage"){
                    $(".input-group-text").text("%")
                    $("input[name='amount']").css('text-indent', 'inherit').prop('disabled', false);
                    $("input[name='extra_amount']").css('text-indent', 'inherit').prop('disabled', false);
                }else if ($this.val() === "flat"){
                    $(".input-group-text").text("$")
                    $("input[name='amount']").css('text-indent', 'inherit').prop('disabled', false);
                    $("input[name='extra_amount']").css('text-indent', '-1000px').prop('disabled', true);
                }else if ($this.val() === "free_shipping"){
                    $(".input-group-text").text("");
                    $("input[name='amount']").css('text-indent', '-1000px').prop('disabled', true);
                    $("input[name='extra_amount']").css('text-indent', '-1000px').prop('disabled', true);
                }else {
                    $(".input-group-text").text("");
                    $("input[name='amount']").css('text-indent', '-1000px').prop('disabled', true);
                    $("input[name='extra_amount']").css('text-indent', '-1000px').prop('disabled', true);
                }
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Backend.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\heyblinds\resources\views/admin/promo/edit.blade.php ENDPATH**/ ?>