<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sample Orders Address Labels</title>
</head>

<body>

    <table>
        <tr>
            <td><h4>Sample Order Id</h4></td>
            <td><h4>Shipping Address</h4></td>
            
        </tr>

    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($order->sample_order_id); ?> </td>
            <td>
                <p><?php echo e($order->shippingAddress->first_name ?? ''); ?> <?php echo e($order->shippingAddress->last_name ?? ''); ?></p>
                <p> <?php echo e($order->shippingAddress->street ?? ''); ?><?php if(!empty($order->shippingAddress->area_code)): ?>, <?php echo e($order->shippingAddress->area_code ?? ''); ?><?php endif; ?></p>
                <p><?php echo e($order->shippingAddress->city ?? ''); ?>, <?php echo e($order->shippingAddress->province ?? ''); ?> </p>
                <p> <?php echo e($order->shippingAddress->postal_code ?? ''); ?></p>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>

</html>
<?php /**PATH D:\Project\heyblinds\resources\views/exports/sample-orders-address.blade.php ENDPATH**/ ?>