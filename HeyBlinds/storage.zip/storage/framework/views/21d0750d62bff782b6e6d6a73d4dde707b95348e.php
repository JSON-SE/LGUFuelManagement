
<div class="h-100 w-100 d-flex pt-4 justify-content-center">
    <form id="home_media_form" class="border p-3 rounded-3" action="">
          <?php echo $__env->make('partial.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="avatar-upload">
            <label >Upload image for Homepage  </label>
            
            <div class="avatar-preview mt-2">
                
                <img id="banner-image-up" src="<?php echo e($helpers->getImage($product->home_media_id)); ?>" alt=""/>
            </div>
            <div class="avatar-edit mt-3">
                <input type="hidden" name="product_id" value="<?php echo e($productID); ?>">
                <input onchange="document.getElementById('banner-image-up').src = window.URL.createObjectURL(this.files[0])" type="file" class="form-control" name="home_media_id" accept=".png, .jpg, .jpeg">
                <label for="imageUpload"></label>
            </div>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
   
</div>





<?php $__env->startPush('js'); ?>

<script type="text/javascript">
    $(document).on('submit', "#home_media_form", function(e) {
        e.preventDefault();
        let formData = new FormData(this)
        $("#loader").show();
        axios.post(`/admin/product/home-media-form`,formData)
        .then((response) =>{
            $("#loader").hide();
            if(response.data.status == true){
               toastr.success(response.data.message);
            }
        })
        .catch((error) =>{
            toastr.error('Something went wrong.');
        })
    });
</script>
<?php $__env->stopPush(); ?><?php /**PATH D:\Project\heyblinds\resources\views/admin/product/partials/home-page-image.blade.php ENDPATH**/ ?>