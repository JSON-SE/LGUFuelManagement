
<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('admin.promo.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>
        <section id="body-content" class="">
        <div class="container-fluid px-lg-5 px-md-4 pb-5 pt-lg-3">
            <div class="row pt-4">
                <div class="col-12">
                    <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='white'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
                        <ol class="breadcrumb mb-2">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Add Promos</li>
                        </ol>
                    </nav>
                </div>
            </div>
            <div class="row pb-4">
                <div class="col-sm-6 text-white my-auto">
                    <h3 class="mb-0">Create Promo</h3>
                    <p id="demo"></p>
                </div>
                <div class="col-sm-6 pt-3 pt-lg-0 my-auto d-flex justify-content-sm-end">
                    <a href="<?php echo e(route('admin.promo.index')); ?>" class="btn btn-primary">All Promos</a>
                    
                </div>

            </div>

            <div class="bg-white rounded page-height mt-3 shadow">
              <?php echo $__env->make('partial.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="p-4">
                    <div class="row">
                        <div class="col-lg-3 col-md-6">
                            <div class="form-floating mt-3">
                                <input type="text" class="form-control" name="name" id="name" value="<?php echo e(old('name')); ?>" placeholder="Promo Name" >
                                <label for="name">Promo Title <span class="text-primary">*</span></label>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="form-floating mt-3">
                                <select name="type" id="type" class="form-select" >
                                    <option value="">Select Type</option>
                                    <option value="percentage" <?php echo e(old('type') == 'percentage' ? 'selected' : ''); ?>>Percentage</option>
                                    <option value="flat" <?php echo e(old('type') == 'flat' ? 'selected' : ''); ?>>Fixed Amount</option>
                                    <option value="free_shipping" <?php echo e(old('type') == 'free_shipping' ? 'selected' : ''); ?>>Free Shipping</option>
                                </select>
                                <label for="type">Promo Type <span class="text-primary">*</span></label>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-6">
                            <div class="input-group mt-3">
                                <span class="input-group-text">%</span>
                                <input type="number" class="form-control" value="<?php echo e(old('amount')); ?>" name="amount" maxlength="3" id="amountField" max="999" aria-label="Amount (to the nearest dollar)" >
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-6">
                        <div class="input-group mt-3">
                            <span class="input-group-text">%</span>
                            <input type="number" class="form-control" value="<?php echo e(old('extra_amount')); ?>" name="extra_amount" maxlength="3" id="amountField" max="999" aria-label="Amount (to the nearest dollar)" >
                        </div>
                        </div>
                        <div class="col-lg-2 col-md-6">
                            <div class="form-floating mt-3">
                                <input type="datetime-local" class="form-control" id="start_date" step="1" name="start_date"   value="<?php echo e(old('start_date')); ?>" placeholder="Start Date" min="<?php echo e(date("Y-m-d")."T".date("H:i:s")); ?>">
                                <label for="start_date">Start Date<span class="text-primary">*</span></label>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-6">
                            <div class="form-floating mt-3">
                                <input type="datetime-local" class="form-control" id="end_date" step="1" name="end_date" value="<?php echo e(old('end_date')); ?>"placeholder="End Date" min="<?php echo e(date("Y-m-d")."T".date("H:i:s")); ?>">
                                <label for="end_date">End Date<span class="text-primary">*</span></label>
                            </div>
                        </div> 
                    
                       <div class="col-lg-3 col-md-6">
                           <div class="mt-3">
                               <input class="form-control form-control-lg" type="file" id="formFile" name="banner" accept="image/*">
                           </div>

                       </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="form-floating mt-3">
                                <input type="text" class="form-control" name="banner_link" id="banner_link" value="<?php echo e(old('banner_link')); ?>" placeholder="Message Bar Text" >
                                <label for="banner_link">Banner Link</label>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="form-floating mt-3">
                                <input type="text" class="form-control" name="ticker" id="ticker" value="<?php echo e(old('ticker')); ?>" placeholder="Message Bar Text" >
                                <label for="ticker">Message Bar Text</label>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="check-box d-inline-block mt-4">
                                <input type="checkbox" id="is_active" name="is_active" value="1" checked="">
                                <label for="is_active">Active</label>
                            </div>
                        
                            <div class="check-box d-inline-block mt-4 ms-4">
                                <input type="checkbox" id="hide_timer" name="hide_timer" value="1" >
                                <label for="hide_timer">Hide Timer</label>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                                <div class="form-floating mt-3">
                                        <input type="text" class="form-control" name="mob_text_bar" id="mob_text_bar" value="<?php echo e(old('mob_text_bar')); ?>" placeholder="Message Bar Text" >
                                        <label for="ticker">Message Bar  for mobile </label>
                                </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating mt-3">
                                    <input type="text" class="form-control" name="coupon_text_box" id="coupon_text_box"   value="<?php echo e(old('coupon_text_box')); ?>"  placeholder="Enter coupon box message"/>
                                    <label for="ticker">Enter coupon box message </label>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-3 d-none">
                        <div class="col-md-6 mt-3">
                            <label class="pb-2" for="category_id">Category And Sub-category</label>
                            <select class="form-control add-colour-name" multiple="multiple" id="category_id" name="category_id[]">
                                <?php $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-6 mt-3">
                            <label class="pb-2" for="product_id">Product Name</label>
                            <select class="form-control add-colour-name" id="product_id" multiple="multiple" name="product_id[]">
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="row">   
                        <div class="col-lg-12">
                            <div class="mt-3">
                                <label for="content" class="mb-2 fw-bold">Detail Promo Description  </label>
                                <textarea id="content" name="content" class="summernote" <?php echo e($errors->has('content') ? ' bg-light-danger' : ''); ?>  class="<?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" ><?php echo e(old('content')); ?></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 mt-5 text-end">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </div>
        </div>
    </section>
    </form>
<?php $__env->startPush('js'); ?>

    <script>
        function isNumber (o) {
            return ! isNaN (o-0);
        }
        function typeOfCoupon(value){
            if (value === "percentage"){
                    $(".input-group-text").text("%")
                     $("input[name='amount']").css('text-indent', 'inherit').prop('disabled', false);
                     $("input[name='extra_amount']").css('text-indent', 'inherit').prop('disabled', false);
                }else if (value === "flat"){
                    $(".input-group-text").text("$")
                     $("input[name='amount']").css('text-indent', 'inherit').prop('disabled', false);
                     $("input[name='extra_amount']").css('text-indent', 'inherit').prop('disabled', true);
                }else if (value === "free_shipping"){
                    $(".input-group-text").text("");
                    $("input[name='value']").css('text-indent', '-1000px').prop('disabled', true);
                }else {
                    $(".input-group-text").text("");
                    $("input[name='amount']").css('text-indent', '-1000px').prop('disabled', true);
                    $("input[name='extra_amount']").css('text-indent', '-1000px').prop('disabled', true);
                }
        }
        $(document).ready(function(){
            var value = $('#type').val();
            if(value){
                typeOfCoupon(value);
            }
        })
        $(document).on('keyup', "#amountField", function(e){
            let txtVal = $(this).val();
            if(isNumber(txtVal) && txtVal.length>3)
            {
                $(this).val(txtVal.substring(0,3) )
            }
        });
        jQuery(function ($) {
            if ($("#type").val() === ""){
                $(".input-group-text").text("");
                $("input[name='amount']").css('text-indent', '-1000px').prop('disabled', true);
                $("input[name='extra_amount']").css('text-indent', '-1000px').prop('disabled', true);
            }
            $(document).on('change', "#type", function (e) {
                e.preventDefault();
                let value = $(this).val();
                typeOfCoupon(value);
            })
        })
    </script>

    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Backend.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\heyblinds\resources\views/admin/promo/create.blade.php ENDPATH**/ ?>