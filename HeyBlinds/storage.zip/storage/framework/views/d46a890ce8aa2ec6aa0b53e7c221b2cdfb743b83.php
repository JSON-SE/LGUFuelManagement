<footer class="bg-dark py-4 text-white" id="footer">
    <div class="container py-2">
        
            <div class="row pb-4">
                <div class="col-md-6 ">
                    <div class="d-flex">
                        <span class="footer-chat-icon text-primary">
                            <svg class="bi bi-headset" fill="currentColor" height="16" viewbox="0 0 16 16"
                                width="16" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M8 1a5 5 0 0 0-5 5v1h1a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V6a6 6 0 1 1 12 0v6a2.5 2.5 0 0 1-2.5 2.5H9.366a1 1 0 0 1-.866.5h-1a1 1 0 1 1 0-2h1a1 1 0 0 1 .866.5H11.5A1.5 1.5 0 0 0 13 12h-1a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1h1V6a5 5 0 0 0-5-5z">
                                </path>
                            </svg>
                        </span>
                        <p class="ps-2 mb-0">
                            Call
                            <a class="text-white fw-bold mx-1" href="tel:(888) 412-3439">
                                (888) 412-3439
                            </a>
                        </p>
                    </div>
                    <p class="pt-2 pe-lg-5 mb-0">
                        Monday - Friday 9AM-11PM EST
                    </p>
                </div>
                <div class="col-md-6 text-md-end">
                    <a class="btn btn-width custom btn-secondary py-2 my-2" href="<?php echo e(route('frontend.category', 'blinds-and-shades')); ?>">Shop Now</a>

                    <a class="btn btn-width custom btn-primary py-2 ms-2 my-2" href="<?php echo e(url('/samples')); ?>">Order Free Samples</a>

            </div>
        </div>

            
        <hr class="m-0" />
        <div class="row">
            <div class="col-lg-4 pt-4">
                <div class="footer-logo">
                    <a href="<?php echo e(route('welcome')); ?>">
                        <img alt="hey blindes logo" src="<?php echo e(asset('images/logo.png')); ?>" />
                    </a>
                </div>
                <h5 class="pt-3 pe-lg-5">
                    Simple to order. Easy to love.
                </h5>
                <ul class="footer-social-media d-flex pt-3">
                    <li>
                        <a href="https://www.bbb.org/ca/qc/montreal/profile/online-retailer/heyblindsca-0117-226511"
                            target="_blank">
                            <img alt="" src="<?php echo e(asset('images/bbb-logo.png')); ?>" />
                        </a>
                    </li>
                    <li>
                        <img alt="" src="<?php echo e(asset('images/lets-encrypt.png')); ?>" />
                    </li>
                </ul>
                
            </div>
            <div class="col-md-7 col-lg-5 pt-4 ps-lg-5">
                <h2>
                    BLINDS AND SHADES
                </h2>
                <ul class="footer-menu d-flex flex-wrap">
                    <?php $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($subCategory->product->count() > 0 && !empty($subCategory->category->slug)): ?>
                    <li class="w-50 text-uppercase">
                        <a class="text-uppercase"
                            href="<?php echo e(route('frontend.category.sub-category', [$subCategory->category->slug, $subCategory->slug])); ?>">
                            <?php echo e($subCategory->name); ?>

                        </a>
                    </li>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <div class="col-md-5 col-lg-3 pt-4 ps-lg-5">
                <h2>
                    GET HELP
                </h2>
                <ul class="footer-menu">
                    <li>
                        <a href="<?php echo e(url('/measure-instructions')); ?>">
                            MEASURE INSTRUCTIONS
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('frontend.warranty')); ?> ">
                            HEYOK WARRANTY
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('frontend.about')); ?> ">
                            ABOUT US
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/terms-and-conditions')); ?> ">
                            POLICIES
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('frontend.faq')); ?> ">
                            FAQ
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/reviews-of-HeyBlinds')); ?> ">
                            CUSTOMER REVIEWS
                        </a>
                    </li>

                    
                </ul>
            </div>
        </div>
    </div>
</footer>
<div class="footer-bottom py-3 text-white">
    <div class="container">
        <div class="row align-items-center flex-wrap justify-content-between text-center text-lg-start">
            <div class="col-auto">
                <img alt="" src="<?php echo e(asset('images/ca-flag.jpg')); ?>" />
                <a class="ps-2" href="<?php echo e(route('welcome')); ?>"> HeyBlinds.ca</a> is a Canadian company, all prices in
                CAD.&nbsp; | &nbsp;All contents ©2021 HeyBlinds. All rights reserved
            </div>
            <div class="col pt-2 pt-sm-0">
                <img alt="" src="<?php echo e(asset('images/payment-card.png')); ?>" />
            </div>
        </div>
    </div>
</div>
<div class="tooltip-bg"></div><?php /**PATH D:\Project\heyblinds\resources\views/layouts/Frontend/partials/blog_footer.blade.php ENDPATH**/ ?>