<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Heyblinds</title>
</head>
<body>
    <br/>
    Cart # :<?php echo e($cart_id); ?> <br/>
    Coupon Code : <?php echo e($coupon_code); ?> <br/>
    Cart Amount : $<?php echo e(number_format($cart_amount,2)); ?> <br/>
    Message : <?php echo html_entity_decode($text); ?><br/>

</body>
</html><?php /**PATH D:\Project\heyblinds\resources\views/emails/coupon.blade.php ENDPATH**/ ?>