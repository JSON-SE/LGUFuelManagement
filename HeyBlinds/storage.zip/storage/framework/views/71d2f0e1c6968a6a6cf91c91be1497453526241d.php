
<?php $__env->startSection('content'); ?>

<section id="body-content" class="">
    <div class="container-fluid px-lg-5 px-md-4 pb-5 pt-lg-3">
        <div class="row pt-4">
            <div class="col-12">
                <nav>
                    <ol class="breadcrumb mb-2">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">
                            Order details
                        </li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="row pb-4">
            <div class="col-sm-6 text-white my-auto">
                <h3 class="mb-0">Sample Order (<?php echo e($order->sample_order_id); ?>)</h3>
            </div>

            <div class="col-sm-6 pt-3 pt-lg-0 my-auto d-flex justify-content-sm-end">

                

                <a href="<?php echo e(route('admin.samples.index')); ?>" class="btn btn-primary d-flex align-items-center ms-2">
                   
                    <span class="d-none d-md-block">Sample Orders</span>
                </a>

            </div>
        </div>

        <div class="bg-white rounded page-height mt-3 shadow p-4">
            <div
                class="<?php echo e($helpers->changeColorForMoreOrder($order->sample_cart_external_id) == true  ? 'bg-primary' : 'bg-primary'); ?>  p-2 rounded mb-3 text-white d-flex flex-wrap align-items-center justify-content-between">
                <p class="mb-0">
                    Order status: <?php echo e($status); ?> <?php echo e(date("Y-m-d h.i A",strtotime($order->updated_at))); ?>

                </p>
                <p class="mb-0">Order ID: <?php echo e($order->sample_order_id); ?></p>
            </div>

            <div class="row">
                <div class="col-md-4 mb-3">
                    <h5>Shipping information</h5>
                    <p class="mb-2"><input type="text" class="edit-input table-input"
                            value="<?php echo e($address->first_name); ?> <?php echo e($address->last_name); ?>" name="" readonly>
                    </p>
                    <p class="mb-2"><input type="text" class="edit-input table-input"
                            value=" <?php echo e($address->street); ?>, <?php echo e($address->area_code); ?>"
                            name="" readonly></p>
                    <p class="mb-2"><input type="text" class="edit-input table-input"
                            value="<?php echo e($address->city); ?>, <?php echo e($address->province); ?>,"
                            name="" readonly></p>
                    <p class="mb-2"><input type="text" class="edit-input table-input"
                            value="<?php echo e($address->postal_code); ?>"
                            name="" readonly></p>
                    <p class="mb-2">
                        <a href="#"><input type="text" class="edit-input table-input"
                                value="<?php echo e($address->email); ?>" name="" readonly></a>
                    </p>
                    <p class="mb-2"><a href="#"><input type="text" class="edit-input table-input"
                                value="<?php echo e($address->phone_number); ?>" name="" readonly></a></p>
                </div>
              
                <div class="col-md-4 mb-3">
                    <div>
                        <label class="pb-2 mt-2">Order Status</label>
                        <select class="form-select" aria-label="Default select example" id="order_status">
                            <?php $__currentLoopData = $orderStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($status->id); ?>" <?php echo e($order->order_status == $status->id ?
                                "selected" : ''); ?>><?php echo e($status->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <input type="hidden" name="current" id="current" value="<?php echo e($order->order_status); ?>" />
                    </div>

                    <div>
                        <label class="pb-2 mt-2">Shipping Date</label>
                        <input type="date" class="form-control" name="shipping_date" id="shipping_date" value="<?php echo e($order->order_shipped); ?>" />
                    </div>

                </div>

                <div class="col-md-4 mb-3">
                    <div>
                        <label class="pb-2 mt-2">Shipping Method</label>
                        <select class="form-select" aria-label="Default select example" id="shipping_method">
                            <option value="1" <?php echo e($order->shipping_type == 1 ? 'selected' : ''); ?>>Courier</option>
                            <option value="0" <?php echo e($order->shipping_type == 0 ? 'selected' : ''); ?> >Regular Mail</option>
                        </select>
                        <input type="hidden" name="current_shipping" id="current_shipping" value="<?php echo e($order->delivery); ?>" />
                    </div>

                    <div>
                        <label class="pb-2 mt-2">Tracking Number</label>
                        <input type="text" class="form-control" name="order_tracking_number" id="order_tracking_number" value="<?php echo e($order->order_tracking_number); ?>" />
                    </div>

                </div>
            </div>
            <div class="row pt-2">
                <form>
                    <div class="row">
                        <div class="col-sm-6 mb-3">
                            <h5>Customer note</h5>
                            <div class="shadow-sm p-3 mb-3 rounded customer_note_list">
                                <h6 class="text-secondary"><?php echo e($order->first_name); ?></h6>
                                <hr class="my-2" />
                                <?php $__currentLoopData = $order->notes->where('receiver','customer'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cnote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="txt__sm mb-0">
                                    <?php echo e($cnote->note); ?>

                                </p>
                                <small>
                                    <?php echo e($cnote->created_at->DIFFfORhUMANS()); ?>

                                </small>
                                <hr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <form method="post" action="">
                                <textarea class="form-control mb-3" rows="5" name="customer_note" id="customer_note"
                                    placeholder="Message"></textarea>
                                <input type="hidden" name="corder_id" id="corder_id" value="<?php echo e($order->id); ?>">
                                <select class="btn btn-primary" name="customer" id="customer">
                                    <option value="customer">Select Action</option>
                                    <option value="customer">Send to Customer</option>
                                    <option value="internally">Save it Internally</option>
                                </select>
                            </form>
                        </div>
                        <div class="col-sm-6 mb-3">
                            <h5>Vendor note</h5>
                            <div class="shadow-sm p-3 mb-3 rounded vendor_note_list">
                                <h6 class="text-secondary"><?php echo e(@$order->customer->customer_first_name); ?> NC</h6>
                                <hr class="my-2" />
                                <?php $__currentLoopData = $order->notes->where('receiver','vendor'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cnote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="txt__sm mb-0">
                                    <?php echo e($cnote->note); ?>

                                </p>
                                <small>
                                    <?php echo e($cnote->created_at->DIFFfORhUMANS()); ?>

                                </small>
                                <hr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <form method="post" action="">
                                <textarea class="form-control mb-3" rows="5" name="vendor_note" id="vendor_note"
                                    placeholder="Message"></textarea>
                                <input type="hidden" name="vorder_id" id="vorder_id" value="<?php echo e($order->id); ?>">
                                <select class="btn btn-primary" name="vendor" id="vendor">
                                    <option value="vendor">Select Action</option>
                                    <option value="vendor">Send to Vendor</option>
                                    <option value="internally">Save it Internally</option>
                                </select>

                            </form>
                        </div>
                    </div>
                </form>
            </div>
            <div class="row pt-4 align-items-center">
                <div class="col-sm-4 mb-3">
                    <h5 class="mb-0 d-flex"><p id="line_items"><?php echo e(count($order->orderEntries)); ?></p><p class="mx-1">LINE ITEMS</p></h5>
                </div>

                <div class="col-sm-8 mb-3">
                    <div class="d-flex align-items-center flex-wrap justify-content-sm-end line-items-btn">
                    
                        <button type="button" class="btn btn-secondary me-2">
                            <svg xmlns="http://www.w3.org/2000/svg" class="me-1" width="14" height="14"
                                fill="currentColor" viewBox="0 0 16 16">
                                <path
                                    d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z" />
                            </svg>
                            <small>Add item</small>
                        </button>
                       
                    </div>
                </div>
            </div>

            <?php $__currentLoopData = $order->orderEntries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="bg-light rounded mb-4 p-4" id="entry_id<?php echo e($entry->id); ?>">

                <h5>
                    HB Product Name:  <?php echo e($entry->product->name ?? ""); ?>

                </h5>
                <hr />
                <div class="row">
                    <div class="col-lg-4">
                        <ul class="payment-history txt__sm">
                            <li>
                                <p class="mb-2 me-3 fw-bold">HB Color #</p>
                                <p class="mb-2"><input type="text" class="edit-input table-input"
                                        value=" <?php echo e($entry->color->color_id); ?>" name="" readonly></p>
                            </li>
                            <li>
                                <p class="mb-2 me-3 fw-bold">HB Color Name</p>
                                <p class="mb-2"><input type="text" class="edit-input table-input"
                                        value=" <?php echo e($entry->color->name); ?>" name="" readonly></p>
                            </li>

                            <li>
                                <p class="mb-2 me-3 fw-bold">Vendor Color Name</p>
                                <p class="mb-2"><input type="text" class="edit-input table-input"
                                        value=" <?php echo e($entry->color->vendor_color_name); ?>" name="" readonly></p>
                            </li>

                            <li>
                                <p class="mb-2 me-3 fw-bold">HB Location #</p>
                                <p class="mb-2"><input type="text" class="edit-input table-input"
                                        value=" <?php echo e($entry->color->id); ?>" name="" readonly></p>
                            </li>

                            
                            

                        </ul>
                    </div>

                    
                    

                    

                    

                </div>

            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>




</section>


<script>
    $( document ).ready( function( $ ) {

        host = "<?php echo e(url('admin/sample-note')); ?>";

        $("#vendor").on("change",function(e){
            // debugger

            e.stopImmediatePropagation();
            // e.preventDefault();
            var note = $('#vendor_note').val();
            var order_id = $('#vorder_id').val();
            var receiver = "vendor";
            var action = $('#vendor').val();
            console.log(note);
            // console.log(order_id);
            // console.log(action);
            // return false;
            $("#alert_message").text("Are you sure?");
            $("#exampleModaltwo").modal('show');
            $("#model-yes").on("click",function(x){

                $("#exampleModaltwo").modal('hide');

                if(note != ""){
                    $.ajax({
                        type: "POST",
                        url: host,
                        data: {note:note, order_id:order_id, receiver:receiver},
                        success: function( msg ) {
                            if(msg.status){
                                $(".vendor_note_list").append("<p class='txt__sm mb-0'>"+note+"</p><small>0 seconds ago </small><hr/>");
                                $("#vendor_note").val("");
                                $(".vendor_note_list").scrollTop($(".vendor_note_list")[0].scrollHeight);
                                $('#vendor_note').val("");
                            }
                        }
                    });

                }
            });

       });

        $("#customer").on("change",function(e){
            e.preventDefault();
            var note = "";
            var note = $('#customer_note').val();
            var order_id = $('#corder_id').val();
            var receiver = "customer";
            var action = $('#customer').val();
            // console.log(note);
            // console.log(order_id);
            // console.log(action);
            // return false;
               // return false;
            $("#alert_message").text("Are you sure?");
            $("#exampleModaltwo").modal('show');
            $("#model-yes").on("click",function(x){

                $("#exampleModaltwo").modal('hide');

                console.log(note);

                if(note != ""){
                    $.ajax({
                        type: "POST",
                        url: host,
                        data: {note:note, order_id:order_id, receiver:receiver},
                        success: function( msg ) {
                            if(msg.status){
                                $(".customer_note_list").append("<p class='txt__sm mb-0'>"+note+"</p><small>0 seconds ago </small><hr/>");
                                $("#customer_note").val("");
                                $(".customer_note_list").scrollTop($(".customer_note_list")[0].scrollHeight);
                            }
                        }
                    });
                }
            });
       });


       statusChange = "<?php echo e(url('admin/change-sample-order-status')); ?>";

        $("#order_status").on("change",function(e){
            e.preventDefault();
            var status = $('#order_status').val();
            var order_id = "<?php echo e($order->id); ?>";
            var current = $('#current').val();
            $("#alert_message").text("Are you sure want to change the status?");
            $("#exampleModaltwo").modal('show');
            $("#model-no").on("click",function(){
                $("#order_status").val(current).change();
                // $("#order_status option[value="+status+"]").attr('selected',true);
                // $(`#order_status option[value='${status}']`).prop('selected', true).change();
                // $(this).val(current);
            });

            $("#model-yes").on("click",function(x){

                $("#exampleModaltwo").modal('hide');
                $.ajax({
                    type: "POST",
                    url: statusChange,
                    data: {status:status, order_id:order_id},
                    success: function( msg ) {
                        if(msg.status){
                            console.log(msg);
                            // $(".customer_note_list").append("<p class='txt__sm mb-0'>"+note+"</p><small>0 seconds ago </small><hr/>");
                            // $("#customer_note").val("");
                            // $(".customer_note_list").scrollTop($(".customer_note_list")[0].scrollHeight);
                        }
                    }
                });
            });
       });


       deleteEntry = "<?php echo e(url('admin/delete-order-entry')); ?>";

        $(".delete_entry").on("click",function(e){
            e.preventDefault();

            // alert("ok");
            // return false;
            // var id = $(this).data("id");
            // alert(id);
            // return false;

            var entry_id = $(this).data("id");
            var order_id = "<?php echo e($order->id); ?>";

            item_count = $("#line_items").text();
            // item_count = item_count - 1;
            // $("#line_items").text(item_count);
            // alert(item_count);
            // return false;


            $("#alert_message").text("Are you sure want to delete the item?");
            $("#exampleModaltwo").modal('show');
            $("#model-yes").on("click",function(x){

                $("#exampleModaltwo").modal('hide');
                $.ajax({
                    type: "POST",
                    url: deleteEntry,
                    data: {order_id:order_id, entry_id:entry_id},
                    success: function( msg ) {
                        console.log(msg);
                        // $("#entry_id"+entry_id).css('display','none');
                        if(msg.status){
                            $("#entry_id"+entry_id).css('display','none');
                            item_count = item_count - 1;
                            $("#line_items").text(item_count);
                            // $(".customer_note_list").append("<p class='txt__sm mb-0'>"+note+"</p><small>0 seconds ago </small><hr/>");
                            // $("#customer_note").val("");
                            // $(".customer_note_list").scrollTop($(".customer_note_list")[0].scrollHeight);
                        }
                    }
                });
            });
       });


       shippingChange = "<?php echo e(url('admin/change-sample-order-shipping-method')); ?>";

        $("#shipping_method").on("change",function(e){
            e.preventDefault();
            var shipping = $('#shipping_method').val();
            var order_id = "<?php echo e($order->id); ?>";
            var current = $('#current_shipping').val();
            $("#alert_message").text("Are you sure want to change the Shipping Method?");
            $("#exampleModaltwo").modal('show');
            $("#model-no").on("click",function(){
                $("#shipping_method").val(current).change();
                // $("#shipping_method option[value="+status+"]").attr('selected',true);
                // $(`#shipping_method option[value='${status}']`).prop('selected', true).change();
                // $(this).val(current);
            });

            $("#model-yes").on("click",function(x){
                $("#exampleModaltwo").modal('hide');
                $.ajax({
                    type: "POST",
                    url: shippingChange,
                    data: {shipping:shipping, order_id:order_id},
                    success: function( msg ) {
                        console.log(msg);
                        if(msg.status){
                            console.log(msg);
                        }
                    }
                });
            });
        });


       shippingDateChange = "<?php echo e(url('admin/change-sample-order-shipping-date')); ?>";

        $("#shipping_date").on("change",function(e){
            e.preventDefault();
            var shippingDate = $('#shipping_date').val();
            var order_id = "<?php echo e($order->id); ?>";
            var current = $('#current_shipping').val();
            $("#alert_message").text("Are you sure want to change the shippingDate Method?");
            $("#exampleModaltwo").modal('show');
            $("#model-no").on("click",function(){
                $("#shipping_date").val(current).change();
            });

            $("#model-yes").on("click",function(x){
                $("#exampleModaltwo").modal('hide');
                $.ajax({
                    type: "POST",
                    url: shippingDateChange,
                    data: {shippingDate:shippingDate, order_id:order_id},
                    success: function( msg ) {
                        console.log(msg);
                        if(msg.status){
                            console.log(msg);
                        }
                    }
                });
            });
        });


       shippingOrderTracking = "<?php echo e(url('admin/change-sample-order-shipping-tracking')); ?>";

        $("#order_tracking_number").on("change",function(e){
            e.preventDefault();
            var trackingNumber = $('#order_tracking_number').val();
            var order_id = "<?php echo e($order->id); ?>";
            var current = $('#current_shipping').val();
            $("#alert_message").text("Are you sure want to change the trackingNumber Method?");
            $("#exampleModaltwo").modal('show');

            // $("#model-no").on("click",function(){
            //     $("#order_tracking_number").val(current).change();
            // });

            $("#model-yes").on("click",function(x){
                $("#exampleModaltwo").modal('hide');
                $.ajax({
                    type: "POST",
                    url: shippingOrderTracking,
                    data: {trackingNumber:trackingNumber, order_id:order_id},
                    success: function( msg ) {
                        console.log(msg);
                        if(msg.status){
                            console.log(msg);
                        }
                    }
                });
            });
        });

    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Backend.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\heyblinds\resources\views/admin/sample/order-details.blade.php ENDPATH**/ ?>