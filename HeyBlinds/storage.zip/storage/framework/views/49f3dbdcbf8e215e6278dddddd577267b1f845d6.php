<footer id="footer" class="bg-light py-3 text-dark text-center">
    Copyright © 2021 Hey Blinds. All rights reserved.
</footer>
<?php /**PATH D:\Project\heyblinds\resources\views/layouts/Backend/admin/layouts/_footer.blade.php ENDPATH**/ ?>