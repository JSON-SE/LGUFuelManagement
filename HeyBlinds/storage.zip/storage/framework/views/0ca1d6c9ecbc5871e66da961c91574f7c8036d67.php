
<?php $__env->startSection('title'); ?>
Blinds | Custom Blinds and Shades Online | Window Coverings | Hey Blinds Canada
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<section class="container">
    <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='currentColor'/%3E%3C/svg%3E&#34;);"
    aria-label="breadcrumb">
    <ol class="breadcrumb mb-0 pt-2">
        <li class="breadcrumb-item"><a href="<?php echo e(route('welcome')); ?>">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Customer Reviews</li>
    </ol>
</nav>


</section>

<section id="body-content">
    <div class="container py-4 pb-xxl-5">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="text-center">

                    <div class="d-flex justify-content-center flex-wrap align-items-center">
                        <div class="px-3">
                            <a href="<?php echo e(route('welcome')); ?>" id="logo">
                                <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Hey Blindes logo">
                            </a>
                        </div>
                        <div class="py-2 px-3 total-product-review">

                            <div class="star-width mx-auto">
                                <div class="progress">
                                    <?php
                                        $rating_total_avg_percentage =  ((100/5)*$avgOfReviews);
                                    ?>
                                    <div class="progress-bar" role="progressbar" style="width: <?php echo e($rating_total_avg_percentage); ?>%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                                <div class="star-pro">
                                    <span>★</span>
                                    <span>★</span>
                                    <span>★</span>
                                    <span>★</span>
                                    <span>★</span>
                                </div>
                            </div>
                            <h5 class="mb-0 ps-2 pt-3"><b><?php echo e(number_format($avgOfReviews,1)); ?></b><small>/5 (<?php echo e($reviewsCount); ?> Reviews)</small></h5>
                        </div>
                    </div>

                    
                    
                </div>
            </div>

        </div>

        <h5 class="font-secondary fw-bold mt-3">CUSTOMER REVIEWS</h5>
        <hr class="mb-0"/>
        <div class="row">
            <?php if($reviews->count() > 0): ?>
            <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-6 pt-3">
                <div class="cart-box p-4 rounded" id="cartItem1769">
                    <div class="row">
                        <div class="">
                                <h6 class="mb-0 font-weight-bold fw-semibold">
                                    <?php echo e(ucfirst($review->title_review)); ?>

                                </h6>
                                 <p class="mb-1 fw-semibold">
                                      <?php echo e(ucfirst($review->name)); ?> from <?php echo e($review->city); ?>, <?php echo e($review->province); ?>&nbsp;<?php echo e($review->created_at->format('M d, Y')); ?>

                                    </p>
                                <div class="pb-2 d-flex">
                                    <div class="star-width">
                                        <div class="progress">
                                            <?php
                                            $rating_avg =   ((100/5)*$review->rating_point);
                                            ?>
                                            <div class="progress-bar" role="progressbar" style="width: <?php echo e($rating_avg); ?>%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>

                                        </div>
                                        <div class="star-pro">
                                            <span>★</span>
                                            <span>★</span>
                                            <span>★</span>
                                            <span>★</span>
                                            <span>★</span>
                                        </div>
                                    </div>
                                </div>

                                <div class="">
                                    <h6 class=" w-100 fst-italic text-break pt-3 review-text mb-0">“<?php echo e($review->review); ?>”</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <h4 class="text-center">Data not found yet.</h4>
                <?php endif; ?>
            </div>
            <div class="mt-4 d-flex justify-content-center review-pagination">
                <?php echo e($reviews->links()); ?>

            </div>

        </div>
    </section>

    <?php $__env->startPush('js'); ?>
        <script>
            $(function(){
                $('.review-text').each(function(event){
                    var max_length = 130;
                    if($(this).html().length > max_length){
                        var short_content 	= $(this).html().substr(0,max_length);
                        var long_content	= $(this).html().substr(max_length);
                        
                        $(this).html(short_content+
                                    '<span class="more_text" style="display:none;">'+long_content+'</span>'+
                                    '<a href="#" class="read_more more-dot">...</a> <br/><a href="#" class="read_more small read-text-change">Read More</a>');
                                    
                        $(this).find('a.read_more').click(function(event){ 
                            event.preventDefault();
                            // $(this).hide();
                            $(this).parents('.review-text').find('.more-dot').toggle();
                            $(this).parents('.review-text').find('.more_text').toggle();

                            var ReadLess = $(this).parents('.review-text').find('.read-text-change');

                            if(ReadLess.text() == 'Read More'){
                                ReadLess.text('Read Less');
                            }
                            else{
                                ReadLess.text('Read More');
                            }
                        });	
                    }	
                });
            });
            
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\heyblinds\resources\views/frontend/reviews-of-heyblinds.blade.php ENDPATH**/ ?>