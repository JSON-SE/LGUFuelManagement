 <?php if($productFlitersRooms->count() > 0 || $productFlitersFeatures->count() > 0): ?>
 <a href="javascript:void(0)">Feature/Room</a>
 <div class="dropdown-menu-items">
    <div class="row">
       
        <?php if($productFlitersFeatures->count() > 0): ?>
        <div class="col-lg-7">
            <div class="fw-semibold">Features List:
                <hr class="mt-1 mb-2"/>
            </div>

            <ul class="dropdown-items  row">
                <?php $__currentLoopData = $productFlitersFeatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productFlitersFeature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="col-lg-4"><a href="<?php echo e(url('/shop/'.$productFlitersFeature->slug)); ?>"><?php echo e($productFlitersFeature->name); ?></a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
         <?php if($productFlitersRooms->count() > 0): ?>
        <div class="col-lg-5">
            <div class="fw-semibold">Rooms List:
                <hr class="mt-1  mb-2"/>
            </div>
            <ul class="dropdown-items">
                <?php $__currentLoopData = $productFlitersRooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productFliter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="w-50"><a href="<?php echo e(url('/shop/'.$productFliter->slug)); ?>"><?php echo e($productFliter->name); ?></a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?><?php /**PATH D:\Project\heyblinds\resources\views/layouts/Frontend/partials/shop-menu.blade.php ENDPATH**/ ?>