<div id="loader">
    <div class="loader-body">
        <div class="loader">
            <div class="face">
                <div class="circle"></div>
            </div>
            <div class="face">
                <div class="circle"></div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Project\heyblinds\resources\views/layouts/Backend/admin/layouts/_loader.blade.php ENDPATH**/ ?>