<div class="pt-2 justify-content-center">
    <div class="table-responsive mt-2">
        <table class="table colourtable" id="productColorTable">
            <thead class="text-white bg-secondary">
                <tr>
                    <th scope="col py-2">
                        #
                    </th>
                    <th scope="col py-2">
                        Name
                    </th>
                    <th scope="col py-2">
                        Type
                    </th>
                    <th scope="col py-2">
                        Show
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $filterPorducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filterPorduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="colour-row ui-state-default align-middle" data-id="<?php echo e($filterPorduct->id); ?>">
                    <td>
                        <?php echo e($loop->index+1); ?>

                    </td>
                    <td>
                        <?php echo e($filterPorduct->name); ?>

                    </td>
                    <td>
                        <?php if($filterPorduct->type == 1): ?>
                        Rooms
                        <?php else: ?>
                        Features
                        <?php endif; ?>
                    </td>
                    <td>
                        <input name="product_filter_value[]" type="checkbox" value="<?php echo e($filterPorduct->id); ?>" <?php echo e($filterPorduct->isProductFilter($filterPorduct->id,$productID) == true ? 'checked' : ''); ?>/>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="px-4 pb-4 text-end tab-btn-position">
            <button type="submit" class="btn btn-primary info-submit productFilter" >
                Update
            </button>
        </div>
    </div>
</div>
<script type="text/javascript">

   $(document).on('submit', "#filterForm", function(e) {
        event.preventDefault();
       let $this = $(this);
        let formData = $this.serialize();
         $("#loader").show();
        axios.post(`/admin/product/filter/assign`,formData)
        .then((response) =>{
            $("#loader").hide();
            if(response.data.status == true){
                toastr.success(response.data.message);
            }
        }).catch(e =>{
            $("#loader").hide();
            toastr.error(response.data.message);
        })
    });
</script>
<?php /**PATH D:\Project\heyblinds\resources\views/admin/product/partials/_filter.blade.php ENDPATH**/ ?>