<section id="banner">
    <div class="banner-slider">
        <?php if(!empty($promo->sliders)): ?>

        <?php $__currentLoopData = $promo->sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           
                <div>
                    <a href="<?php echo e($slider->slider_link); ?>">
                        <img src="<?php echo e($helpers->getSliderImage($slider->media_id)); ?>" alt="Hey-Blinds-banner" />
                    </a>
                </div>
          
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <div>
                    <a target="_blank" href="https://www.instagram.com/p/CWaiLfjo2Jq/"> 
                        <img src="<?php echo e(asset('images/banner/HeyHolidayGivewayHPBanner_Rev.png')); ?>" alt="Hey-Blinds-banner" />
                    </a>
                </div>

        <?php else: ?>
        
        <div>
            <a href="https://heyblinds.ca/warranty"> 
                <img src="<?php echo e(asset('images/banner/HeyBlinds-warranty-1920x749.jpg')); ?>" alt="Hey-Blinds-banner" />
            </a>
        </div>
        <?php endif; ?>
    </div>
</section>
<?php /**PATH D:\Project\heyblinds\resources\views/layouts/Frontend/partials/_header-banner.blade.php ENDPATH**/ ?>