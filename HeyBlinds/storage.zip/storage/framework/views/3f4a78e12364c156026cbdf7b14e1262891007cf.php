
<?php $__env->startSection('title'); ?>
    Blinds | Custom Blinds and Shades Online | Window Coverings | Hey Blinds Canada 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section id="body-content">
        <div class="container py-sm-5 py-4 pb-xxl-5">
            <div class="row gx-5">
                <div class="col-lg-8">
                    <div class="text-center p-4 pt-5 bg-secondary rounded ">
                        <h1 class="font-brittan text-white">Thank You!</h1>
                        <h4 class="font-secondary heading-two text-white pt-2">Your order is confirmed!</h4>
                        <p class="text-white">A confirmation email has been sent to your provided email address.</p>
                        <a href="<?php echo e(route('welcome')); ?>" class="btn btn-primary mt-2">Continue Shopping</a>
                    </div>
                </div>
                <div class="col-lg-4 mt-3 mt-lg-0">
                    <div class="shadow rounded text-center p-3 text-cente">
                        <img src="<?php echo e(asset('images/24-hours-outline.png')); ?>" alt="" />
                        <h4 class="pt-3">Have <span class="text-primary">questions?</span></h4>
                        <h5 class="fw-bold"><a href="tel:(888) 412-3439">(888) 412-3439</a></h5>
                        <p class="small">Monday - Friday 9:00 AM - 6:00 PM EST</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->startPush('js'); ?>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('event', 'conversion', {'send_to': '703193369/hwNQCJKhwbECEJnCp88C',
         'value': 1.0,
         'currency': 'USD'
     });
    dataLayer.push({
          'event': 'transactionComplete',
          'transactionId': '<?php echo e($sampleOrder->sample_orders); ?>',         
          'transactionAffiliation': 'HeyBlinds',    
          'transactionTotal':  0.00,             
          'transactionTax': 0.00,                
          'transactionShipping': 0.00,            
          'transactionProducts': <?php echo $dataTag; ?>

  });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\heyblinds\resources\views/frontend/thank-you.blade.php ENDPATH**/ ?>