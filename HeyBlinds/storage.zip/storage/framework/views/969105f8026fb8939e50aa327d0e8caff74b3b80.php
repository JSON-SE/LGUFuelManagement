

<?php $__env->startSection('content'); ?>

    <section id="body-content" class="">
        <div class="container-fluid px-lg-5 px-md-4 pb-5 pt-lg-3">

            <div class="row pt-4">
                <div class="col-12">
                    <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='white'/%3E%3C/svg%3E&#34;);"
                        aria-label="breadcrumb">
                        <ol class="breadcrumb mb-2">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Add Coupons</li>
                        </ol>
                    </nav>
                </div>
            </div>

            <div class="row pb-4">
                <div class="col-sm-6 text-white my-auto">

                    <h3 class="mb-0">Create Coupon</h3>
                </div>


                <div class="col-sm-6 pt-3 pt-lg-0 my-auto d-flex justify-content-sm-end">
                    <!-- <button class="btn btn-light">New view</button> -->
                    <a class="btn btn-primary d-flex align-items-center ms-2" href="<?php echo e(route('admin.coupons.index')); ?>">
                        
                        <span class="d-none d-md-block">View All Coupons</span>
                    </a>
                </div>

            </div>

            <div class="bg-white rounded page-height mt-3 shadow position-relative pb-5">

                <?php if(Session::has('message')): ?>
                    <p class="alert alert-info my-4"><?php echo e(Session::get('message')); ?></p>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="mt-1"><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>


                <div class="p-4 pt-3">

                    <form action="<?php echo e(route('admin.coupons.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="justify-content-center">
                            <div class="color-records pb-3">
                                <div class="row">
                                    <div class="col-lg-3 col-xl-12">
                                        <div class="row gx-2">

                                            <div class="col-lg-3">
                                                <div class="form-floating mt-3">
                                                    <input type="text"
                                                        class="form-control   <?php echo e($errors->has('name') ? ' bg-light-danger' : ''); ?> "
                                                        name="name" value="<?php echo e(old('name')); ?>"
                                                        class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        placeholder="Coupon Name" required>
                                                    <label for="">Coupon Name <span class="text-primary">*</span></label>

                                                </div>
                                            </div>

                                            <div class="col-lg-3">
                                                <div class="form-floating mt-3">
                                                    <input type="text"
                                                        class="form-control   <?php echo e($errors->has('code') ? ' bg-light-danger' : ''); ?> "
                                                        name="code" class="<?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        value="<?php echo e(old('code')); ?>" placeholder="Coupon Code" required>
                                                    <label for="">Coupon Code <span class="text-primary">*</span></label>

                                                </div>
                                            </div>

                                            <div class="col-lg-3">
                                                <div class="form-floating mt-3">
                                                    <select class="form-select" id="floatingSelect" name="type" required
                                                        aria-label="Floating label select example">
                                                        <option disabled>Select coupon type</option>
                                                        <option selected value="percentage">Percentage</option>
                                                        <option value="flat">Flat</option>
                                                    </select>
                                                    <label for="">Type</label>
                                                </div>
                                            </div>


                                            <div class="col-lg-3">
                                                <div class="form-floating mt-3">
                                                    <input type="text"
                                                        class="form-control  <?php echo e($errors->has('amount') ? ' bg-light-danger' : ''); ?> "
                                                        id="amount" name="amount"
                                                        class="<?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required
                                                        value="<?php echo e(old('amount')); ?>" placeholder="Discount Amount">
                                                    <label for="">Discount Amount <span class="text-primary">*</span></label>

                                                </div>
                                            </div>


                                            <div class="col-lg-3">
                                                <div class="form-floating mt-3">
                                                    <input type="text"
                                                        class="form-control  <?php echo e($errors->has('min_amount') ? ' bg-light-danger' : ''); ?> "
                                                        id="min_amount" class="<?php $__errorArgs = ['min_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="min_amount" value="<?php echo e(old('min_amount')); ?>"
                                                        placeholder="Minimum Spend Amount">
                                                    <label for="">Minimum Spend Amount</label>
                                                </div>
                                            </div>

                                            <div class="col-lg-2 d-none">
                                                <div class="form-floating mt-3">
                                                    <input type="text"
                                                        class="form-control  <?php echo e($errors->has('min_quantity') ? ' bg-light-danger' : ''); ?> <?php $__errorArgs = ['min_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="min_quantity" name="min_quantity"
                                                        value="<?php echo e(old('min_quantity')); ?>" placeholder="Minimum Quantity">
                                                    <label for="min_quantity">Minimum Quantity</label>
                                                </div>
                                            </div>

                                            <div class="col-lg-3">
                                                <div class="form-floating mt-3">
                                                    <input type="datetime-local" class="form-control" id="start_date"
                                                        name="start_date" required value="<?php echo e(old('start_date')); ?>" step="1"
                                                        placeholder="Start Date" min="<?php echo e(date("Y-m-d")."T".date("H:i:s")); ?>">
                                                    <label for="">Start Date <span class="text-primary">*</span></label>
                                                </div>
                                            </div>

                                            <div class="col-lg-3">
                                                <div class="form-floating mt-3">
                                                    <input type="datetime-local"
                                                        class="form-control  <?php echo e($errors->has('end_date') ? ' bg-light-danger' : ''); ?> "
                                                        id="end_date" class="<?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="end_date" required value="<?php echo e(old('end_date')); ?>" step="1"
                                                        placeholder="Expiration Date" min="<?php echo e(date("Y-m-d")."T".date("H:i:s")); ?>">
                                                    <label for="">Expiration Date <span class="text-primary">*</span></label>


                                                </div>
                                            </div>
                                            
                                            <div class="col-md-2 d-none">
                                                <div class="form-floating mt-3">
                                                    <select class="form-select" id="customer_eligibility" name="coupon_use"
                                                        aria-label="Floating label select example">
                                                        <option selected value="all">Everyone</option>
                                                        <option value="specific">Specific customers</option>
                                                        
                                                    </select>
                                                    <label for="customer_eligibility">Customer Eligibility</label>
                                                </div>
                                            </div>

                                            <div class="col-lg-3">
                                                <div class="form-floating mt-3">
                                                    <select class="form-select" id="coupon_use" name="coupon_use"
                                                        aria-label="Floating label select example">
                                                        <option selected value="1">Once</option>
                                                        <option value="2">Twice</option>
                                                        <option value="99999999">Unlimited</option>
                                                    </select>
                                                    <label for="">Coupon can use</label>
                                                </div>
                                            </div>

                                            <div class="col-lg-3 mt-3">
                                                <div class="upload-group input-group">
                                                    <label class="input-group-text">Icon Upload</label>
                                                    <input
                                                        class="file-name form-control  <?php echo e($errors->has('icon') ? ' bg-light-danger' : ''); ?> "
                                                        type="text" placeholder="Browse"
                                                        class="<?php $__errorArgs = ['icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="icon" readonly="">
                                                    <input type="file" id="icon" name="icon">
                                                    <label class="upload-btn" for="icon">
                                                    </label>
                                                </div>
                                            </div>

                                            <div class="col-lg-2">
                                                <div class="form-floating mt-3">
                                                    <select class="form-select" id="coupon_for" name="coupon_for"
                                                        aria-label="Floating label select example">
                                                        <option selected value="0">New User</option>
                                                        <option value="1">Repeated User</option>
                                                        <option value="2">All</option>
                                                    </select>
                                                    <label for="">Coupon For</label>
                                                </div>
                                            </div>


                                            <div class="col-lg-2 d-flex mt-1">
                                                <div class="check-box d-inline-block mt-4">
                                                    <input type="checkbox" id="with_promo" name="with_promo" value="1">
                                                    <label for="with_promo">Combined with promo</label>
                                                </div>
                                            </div>


                                            
                                            
                                            
                                            
                                            
                                            
                                            

                                            <div class="col-lg-2 d-flex mt-1">
                                                <div class="check-box d-inline-block mt-4">
                                                    <input type="checkbox" id="is_active" name="is_active" value="1"
                                                        checked>
                                                    <label for="is_active">Active</label>
                                                </div>
                                            </div>

                                            <div class="col-md-6 mt-3">
                                                <label class="pb-2">Category Name</label>
                                                <select class="form-control add-colour-name" multiple="multiple"
                                                    name="category_id[]" data-placeholder="Select Categories">
                                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="col-md-6 mt-3">
                                                <label class="pb-2">Product Name</label>
                                                <select class="form-control add-colour-name" multiple="multiple"
                                                    name="product_id[]" data-placeholder="Select Products">
                                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="mt-3">
                                                    <label for="description">Coupon Description <span class="text-primary">*</span></label>
                                                    <textarea id="summernote-excerpt" name="description" class="summernote"
                                                        <?php echo e($errors->has('description') ? ' bg-light-danger' : ''); ?>

                                                        class="<?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('description')); ?></textarea>
                                                </div>
                                            </div>

                                            <div>
                                                <button class="btn btn-primary mt-4">
                                                    Submit
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Backend.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\heyblinds\resources\views/admin/coupons/create.blade.php ENDPATH**/ ?>