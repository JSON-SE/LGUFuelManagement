<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sample All Orders Details</title>
</head>

<body>

    <table>
        <tr>
            <td><h4>Sample Order Id</h4></td>
             <td><h4>Shipping Address</h4></td>
            <td><h4>First Name</h4></td>
            <td><h4>Last Name</h4></td>
             <td><h4>Email Address</h4></td>
            <td><h4>Shipping Method</h4></td>
            <td><h4>HB Product Name</h4></td>
            <td><h4>HB Color Name</h4></td>
            <td><h4>Location #</h4></td>
            
        </tr>

    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 
        <tr>
            <td><?php echo e($order->sample_order_id); ?> </td>
            <td>
                <p><?php echo e($order->shippingAddress->first_name ?? ""); ?> <?php echo e($order->shippingAddress->last_name ?? ""); ?></p>
                <p><?php echo e($order->shippingAddress->street ?? ""); ?><?php if(!empty($order->shippingAddress->area_code)): ?>, <?php echo e($order->shippingAddress->area_code); ?><?php endif; ?>
                  </p>
                <p><?php echo e($order->shippingAddress->city . ", " ?? ""); ?> <?php echo e($order->shippingAddress->province . " " ?? ""); ?></p>
                <p><?php echo e($order->shippingAddress->postal_code ?? ""); ?></p>
            </td>
            <td><p><?php echo e($order->shippingAddress->first_name ?? ""); ?></p></td>
            <td><p><?php echo e($order->shippingAddress->last_name ?? ""); ?></p></td>
            <td><p><?php echo e($order->shippingAddress->email ?? ""); ?></p></td>
            <td><p><?php echo e(( $order->shipping_type == 0 ) ? "Regular Mail" : "Courier"); ?></p></td>
            <?php $__currentLoopData = $order->orderEntries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><h5><?php echo e($entry->product->name ?? ""); ?></h5></td>
                <td><p><?php echo e($entry->color->name ?? ""); ?></p></td>
                <td><p><?php echo e($entry->color->color_id ?? ""); ?></p></td>
                
                </tr><tr><td><td></td><td></td><td></td><td></td><td></td>
                    

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>

</html>
<?php /**PATH D:\Project\heyblinds\resources\views/exports/sample-all-orders.blade.php ENDPATH**/ ?>