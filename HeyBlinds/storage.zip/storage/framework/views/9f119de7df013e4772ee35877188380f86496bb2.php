
<?php $__env->startSection('content'); ?>
<div class="container-fluid px-lg-5 px-md-4 pb-5 pt-lg-3">
    <div class="row pt-4">
        <div class="col-12">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-2">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(route('admin.dashboard')); ?>">
                            Home
                        </a>
                    </li>
                    <li aria-current="page" class="breadcrumb-item active">
                        Edit customer
                    </li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="row pb-4">
        <div class="col-sm-6 text-white my-auto">
            <h3 class="mb-0">
                Edit: <?php echo e($user->full_name); ?>

            </h3>
        </div>
        <div class="col-sm-6 pt-3 pt-lg-0 my-auto d-flex justify-content-sm-end">
            <!-- <button class="btn btn-light">New view</button> -->
            <a class="btn btn-primary d-flex align-items-center" href="<?php echo e(route('admin.customers.index')); ?>">
                <span class="">
                    All Customer
                </span>
            </a>
        </div>
    </div>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="mt-1">
                <?php echo e($error); ?>

            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <form action="<?php echo e(route('admin.customers.update',$user->id)); ?>" enctype="multipart/form-data" method="post">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <div class="bg-white rounded page-height mt-3 shadow position-relative pb-5">
            <div class="p-lg-4 p-3 pb-5">
                <ul class="nav nav-tabs product-management-tab" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button aria-controls="basic" aria-selected="true" class="nav-link active" data-bs-target="#basic" data-bs-toggle="tab" id="basic-tab" role="tab" type="button">
                            Customer Basic
                            Information
                        </button>
                    </li>
                </ul>
                <div class="tab-content" id="myTabContent">
                    <div aria-labelledby="basic-tab" class="tab-pane fade show active" id="basic" role="tabpanel">
                        <div class="pt-2">
                            <div class="row gx-2">
                                <div class="row">
                                    <div class="col-lg-6 mt-3">
                                        <div class="form-floating">
                                            <input class="form-control" id="first_name" name="first_name" placeholder="Fist Name" type="text" value="<?php echo e($user->first_name); ?>"/>
                                            <label for="name">
                                                First Name
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mt-3">
                                        <div class="form-floating">
                                            <input class="form-control" id="last_name" name="last_name" placeholder="Last Name" type="text" value="<?php echo e($user->last_name); ?>"/>
                                            <label for="name">
                                                Last Name
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6 mt-3">
                                        <div class="form-floating">
                                            <input class="form-control" id="email" name="email" placeholder="Email" type="text" value="<?php echo e($user->email); ?>"/>
                                            <label for="name">
                                                Email
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mt-3">
                                        <div class="form-floating">
                                            <input class="form-control phone_number" id="phone_number" maxlength="16" name="phone_number" placeholder="Phone number" type="text" value="<?php echo e($user->profile->phone_number ?? ''); ?>"/>
                                            <label for="name">
                                                Phone Number
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mt-3">
                                        <div class="form-floating">
                                            <input class="form-control " id="password"  name="password" placeholder="Password" type="text" value="<?php echo e($user->profile->passwod ?? ''); ?>"/>
                                            <label for="name">
                                                Password
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 text-center">
                                        <div class="check-box d-inline-block pt-4 ">
                                            <input type="checkbox" id="email_verified_at" name="email_verified_at" <?php echo e(!empty($user->email_verified_at) ? "checked": ""); ?> value="1">
                                            <label for="email_verified_at">Verify Account</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="px-4 pb-4 text-end tab-btn-position">
                                <a class="btn btn-danger" href="<?php echo e(route('admin.customers.index')); ?>">
                                    Back
                                </a>
                                <button class="btn btn-success save-data" data-url="<?php echo e(route('admin.category.store')); ?>" type="submit">
                                    Update
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Backend.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\heyblinds\resources\views/admin/customers/edit.blade.php ENDPATH**/ ?>