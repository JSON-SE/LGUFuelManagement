
<?php $__env->startSection('content'); ?>
<section class="container">
    <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='currentColor'/%3E%3C/svg%3E&#34;);"
    aria-label="breadcrumb">
    <ol class="breadcrumb mb-2 pt-2">
        <li class="breadcrumb-item">
            <a href="<?php echo e(route('welcome')); ?>">
                Home
            </a>
        </li>
        <li class="breadcrumb-item active" aria-current="page">Order Items List</li>
    </ol>
</nav>
</section>


<section id="body-content">
    <div class="container py-3 pb-4 pb-xxl-5">
        <div class="row">
            <div class="col-lg-4">
                <?php echo $__env->make('user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <div class="col-lg-8 pt-4">
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                        <h5 class="font-secondary fw-bold">My Order</h5>
                        <hr class="mt-2" />
                        

                        <div class="pt-2">
                            <?php if($orders->count() > 0 ): ?>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="p-3 shadow-sm mb-3">
                                <div class="row align-content-center">
                                    <div class="col-12">
                                        <div class="row align-content-center">
                                            <div class="fw-bold col-xl-3 col-md-6 "> #: <a class="fw-normal"
                                                > <?php echo e($order->order_id ?? ' '); ?></a></div>
                                                <div class="fw-bold col-xl-3 col-md-3 mt-xl-0">Ordered: <a
                                                    class="fw-normal" > <?php echo e($order->created_at->diffForhumans()); ?></a></div>
                                                    <div class="fw-bold col-xl-1 col-md-6 mt-2 mt-md-0">Qty: 
                                                        <a class="fw-normal"> <?php echo e($order->cart->items->count()); ?></a>
                                                    </div>
                                                   
                                                    <div class="fw-bold col-xl-2 col-md-1 mt-md-0"> 
                                                         <?php if($order->order_status == 10): ?>
                                                        <a class="fw-normal">Transaction failed.</a>
                                                            <?php endif; ?>
                                                    </div>
                                                
                                                    <div class="fw-bold col-xl-3 col-md-6 mt-2 mt-xl-0 text-end"> 
                                                        <a
                                                        class="fw-normal btn btn-sm btn-primary"
                                                        href="<?php echo e(url('user/cart/'.$order->cart->external_id.'/details')); ?>"> View Order
                                                        
                                                    </a>
                                                </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <h4 class="fw-light mb-0 text-center" >No Orders Found!</h4>
                                        
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.Frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\heyblinds\resources\views/user/index.blade.php ENDPATH**/ ?>