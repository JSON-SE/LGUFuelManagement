

<?php $__env->startSection('content'); ?>
    <div class="container py-lg-4">
        <div class="row justify-content-center">

            <div class="col-md-8 mt-4 mb-4">
                <?php echo $__env->make('partial.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="card p-4 p-lg-5 rounded shadow border-0 text-center">
                    <h4 class="card-header bg-white pt-0 px-0 pb-3"><?php echo e(__('Successfully verified your email address.')); ?>

                    </h4>
                    <div class="card-body">
                        <div class="mt-4 mt-md-5">
                            <?php if(auth()->guard()->check()): ?>
                                <a class="btn btn-primary" href="<?php echo e(url('/user/my-account')); ?>">Go To Profile</a>
                            <?php else: ?>
                                <a class="btn btn-primary" href="<?php echo e(url('/login')); ?>">Go To account</a>
                            <?php endif; ?>
                            <?php if($cart_id): ?>
                                <a class="btn btn-primary" href="<?php echo e(route('frontend.checkout',$cart_id)); ?>">View your cart</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\heyblinds\resources\views/auth/successfully-email-verify.blade.php ENDPATH**/ ?>