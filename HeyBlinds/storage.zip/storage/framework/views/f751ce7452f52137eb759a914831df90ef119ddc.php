<!DOCTYPE html>
<html>
<head>
	<title>Heyblinds</title>
</head>
<body>
	<h2><u>User info</u></h2>
		User Name : <?php echo e($user_name); ?><br/>
		email: <?php echo e($email); ?> <br/>
		Phone Number: <?php echo e($phone_number); ?><br/>
		Cart : #<?php echo e($cart_id); ?><br/>
		Cart Amount : $<?php echo e(number_format($cart_amount,2)); ?><br/>
		Cart URL : <a href="<?php echo e($cart_full_path); ?>" target="_blank"><?php echo e($cart_full_path); ?></a><br/>
		<h2>Payment Failed reason</h2>
		Message : <?php echo e($response); ?>

</body>
</html>
<?php /**PATH D:\Project\heyblinds\resources\views/emails/payment-failed.blade.php ENDPATH**/ ?>