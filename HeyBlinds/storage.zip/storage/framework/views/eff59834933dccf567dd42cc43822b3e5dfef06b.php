<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actions Report</title>
</head>

<body>

    <table>
        <tr>
            <td><h4>Email</h4></td>
            <td><h4>First Name</h4></td>
            <td><h4>Last Name</h4></td>
            <td><h4>tel. #</h4></td>
            <td><h4>$customer_action</h4></td>
            <td><h4>Action Date</h4></td>
            <td><h4>Cart Link</h4></td>
            <td><h4>Cart #</h4></td>
            <td><h4>Cart Subtotal</h4></td>
            <td><h4>Province</h4></td>
            <td><h4>Postal Code</h4></td>
        </tr>
        <?php $__currentLoopData = $abandonedCustomers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->shipping_email ?? ''); ?></td>
                <td><?php echo e($user->shipping_first_name ?? ''); ?></td>
                <td><?php echo e($user->shipping_last_name ?? ''); ?></td>
                <td><?php echo e($user->shipping_phone_number ?? ''); ?></td>
                <td>
                    <?php if($user->cart_type== 1): ?>
                    Saved Cart
                    <?php else: ?>
                    Saved Cart and Sample Ordered
                    <?php endif; ?>
               </td>
                <td><?php echo e($user->created_at->format('Y-m-d H:m:s')); ?></td>
                <td><?php echo e($user->makeroute($user)); ?></td>
                <td><?php echo e($user->cart->cart_id ?? ''); ?></td>
                <td><?php echo e(number_format($user->cart->cart_amount ?? '0.00', 2)); ?></td>
                <td><?php echo e($user->shipping_province ?? ''); ?></td>
                <td><?php echo e($user->shipping_postal_code ?? ''); ?></td>
                
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td> <?php echo e($order->shippingAddress->email ?? ''); ?> </td>
            <td> <?php echo e($order->shippingAddress->first_name ?? ''); ?> </td>
            <td> <?php echo e($order->shippingAddress->last_name ?? ''); ?> </td>
            <td> <?php echo e($order->shippingAddress->phone_number ?? ''); ?></td>
            <td>
            <?php if($key == 0): ?>
            <b>Ordered</b>
            <?php else: ?>
            Ordered
            <?php endif; ?>
            </td>
            <td><?php echo e($order->created_at->format('Y-m-d H:m:s')); ?></td>
            <td><?php echo e($order->makeroute($order)); ?></td>
            <td><?php echo e($order->cart->cart_id ?? ''); ?></td>
            <td><?php echo e($helpers->grand_total_amount($order->cart_id ?? '')); ?></td>
            <td><?php echo e($order->shippingAddress->province ?? ''); ?> </td>
            <td><?php echo e($order->shippingAddress->postal_code ?? ''); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php $__currentLoopData = $sample_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $sample): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td> <?php echo e($sample->shippingAddress->email ?? ''); ?> </td>
            <td> <?php echo e($sample->shippingAddress->first_name ?? ''); ?> </td>
            <td> <?php echo e($sample->shippingAddress->last_name ?? ''); ?> </td>
            <td> <?php echo e($sample->shippingAddress->phone_number ?? ''); ?></td>
            <td>
           
                <?php if($sample->order_cart_status == 1): ?>
                <?php if($key == 0): ?>
                   <b>Saved Cart and Sample Ordered</b>
                    <?php else: ?>
                   Saved Cart and Sample Ordered
                    <?php endif; ?>
                    
                <?php else: ?>
                    <?php if($key == 0): ?>
                   <b>Sample Ordered</b>
                    <?php else: ?>
                    Sample Ordered
                    <?php endif; ?>
                <?php endif; ?>
            
            </td>
            <td><?php echo e($sample->created_at->format('Y-m-d H:m:s')); ?></td>
            <td></td>
            <td><?php echo e($sample->sample_order_id); ?></td>
            <td><?php echo e('0.00'); ?></td>
            <td><?php echo e($sample->shippingAddress->province ?? ''); ?> </td>
            <td> <?php echo e($sample->shippingAddress->postal_code ?? ''); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>

</html>
<?php /**PATH D:\Project\heyblinds\resources\views/exports/actions.blade.php ENDPATH**/ ?>