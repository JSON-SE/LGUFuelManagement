<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>c=comment</title>
   
</head>
<body>
    Name : <b><?php echo e($comment->name); ?></b></br>
    Email: <b><?php echo e($comment->email); ?></b></br>
    Message : <b><?php echo e($comment->comment); ?></b>
    
</body>
</html><?php /**PATH D:\Project\heyblinds\resources\views/emails/comment.blade.php ENDPATH**/ ?>