<!DOCTYPE html>
<html>
<head>
    <title>Heyblinds</title>
</head>
<body>
    <p><b>Order ID :</b> #<?php echo e($order_id); ?></p>
    <p><b>Body</b></p>
    <p>Shipping Address : <?php echo e($shippingAddress['street'] ?? ''); ?> <?php echo e($shippingAddress['area_code'] ?? ''); ?><br/>
        <?php echo e($shippingAddress['city']?? ''); ?>, <?php echo e($shippingAddress['province']??''); ?>, <?php echo e($shippingAddress['postal_code']?? ''); ?></p>
        <br/>
    <p>Billing Address : <?php echo e($billingAddress['street'] ?? ''); ?> <?php echo e($billingAddress['area_code']?? ''); ?> <br/>
        <?php echo e($billingAddress['city'] ?? ''); ?>, <?php echo e($billingAddress['province']??''); ?>, <?php echo e($billingAddress['postal_code']?? ''); ?>

    </p>
</body>
</html><?php /**PATH D:\Project\heyblinds\resources\views/emails/shipping-billing-mismatch.blade.php ENDPATH**/ ?>