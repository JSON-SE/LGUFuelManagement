
<?php $__env->startSection('content'); ?>

    <section id="body-content" class="">
        <div class="container-fluid px-lg-5 px-md-4 pb-5 pt-lg-3">
            <div class="row pt-4">
                <div class="col-12">
                    <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='white'/%3E%3C/svg%3E&#34;);"
                        aria-label="breadcrumb">
                        <ol class="breadcrumb mb-2">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Add Extra price</li>
                        </ol>
                    </nav>
                </div>
            </div>
            <div class="row pb-4">
                <div class="col-sm-6 text-white my-auto">
                    <h3 class="mb-0">Extra price</h3>
                </div>
            </div>

            <div class="bg-white rounded page-height mt-3 shadow">
                <?php echo $__env->make('partial.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="p-4 pb-5">
                    <ul class="nav nav-tabs product-management-tab" id="myTab" role="tablist">

                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="Shipping-tab" data-bs-toggle="tab"
                                data-bs-target="#Shipping" type="button" role="tab" aria-controls="Shipping"
                                aria-selected="true">Shipping</button>
                        </li>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="Handling-tab" data-bs-toggle="tab" data-bs-target="#Handling"
                                type="button" role="tab" aria-controls="Handling" aria-selected="false">Handling</button>
                        </li>



                    </ul>

                    <div class="tab-content" id="myTabContent">

                        <div class="tab-pane fade show active" id="Shipping" role="tabpanel" aria-labelledby="Shipping-tab">
                            <div class="pt-2">
                                <form action="<?php echo e(url('/admin/extra-setting-shipping-price')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('post'); ?>
                                    <input type="hidden" name="shipping_price_id" value="<?php echo e($shipping_price->id ?? ''); ?>">
                                    <div class="row">
                                        <div class="col-lg-4 col-md-4">
                                            <div class="form-floating mt-3">
                                                <input type="number" class="form-control" name="min_width" id="min_width"
                                                    value="<?php echo e($shipping_price->min_width??''); ?>" placeholder="Manimum width"
                                                    autocomplete="off" min="94" required>
                                                <label for="min_width">Manimum width <span
                                                        class="text-primary"></span></label>
                                            </div>
                                        </div>
                                     
                                        <div class="col-lg-4 col-md-4">
                                            <div class="form-floating mt-3">
                                                <input type="text" class="form-control" required name="amount" id="amount"
                                                    value="<?php echo e($shipping_price->amount?? ''); ?>" placeholder="Amount">
                                                <label for="amount">Amount<span class="text-primary">*</span></label>
                                            </div>
                                        </div>

                                        <div class="col-lg-4 col-md-6 mt-3">
                                            <button type="submit" class="btn btn-primary">Update</button>
                                        </div>
                                    </div>

                                </form>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="Handling" role="tabpanel" aria-labelledby="Handling-tab">
                            <div class="pt-2">
                                 <div class="tab-pane fade show active" id="Shipping" role="tabpanel" aria-labelledby="Shipping-tab">
                            <div class="pt-2">
                                <form action="<?php echo e(url('/admin/extra-setting-handling-price')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('post'); ?>
                                    <input type="hidden" name="handling_price_id" value="<?php echo e($handling_price->id ?? ''); ?>">
                                    <div class="row">
                                        <div class="col-lg-4 col-md-4">
                                            <div class="form-floating mt-3">
                                                <input type="text" class="form-control" required name="amount" id="amount"
                                                    value="<?php echo e($handling_price->amount?? ''); ?>" placeholder="Amount">
                                                <label for="amount">Amount<span class="text-primary">*</span></label>
                                            </div>
                                        </div>

                                        <div class="col-lg-4 col-md-6 mt-3">
                                            <button type="submit" class="btn btn-primary">Update</button>
                                        </div>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>
</section>

    <?php $__env->startPush('js'); ?>



    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Backend.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\heyblinds\resources\views/admin/extra/shipping.blade.php ENDPATH**/ ?>