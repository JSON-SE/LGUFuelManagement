
<?php $__env->startSection('content'); ?>
<style>
    .customDisabled {
        pointer-events:none;
    }
    .customEnable {
        pointer-events:all;
    }
    .entrySave{
        display:none;
    }
    .input-color{
        color:#2100a1;
    }
    .activeColor{
        color:#000;
    }
</style>

<section id="body-content" class="">
    <div class="container-fluid px-lg-5 px-md-4 pb-5 pt-lg-3">
        <div class="row pt-4">
            <div class="col-12">
                <nav  aria-label="breadcrumb">
                    <ol class="breadcrumb mb-2">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">
                            Order details
                        </li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="row pb-4">
            <div class="col-sm-6 text-white my-auto">
                <h3 class="mb-0">Order Details (<?php echo e($order->order_id); ?>)</h3>
            </div>

            <div class="col-sm-6 pt-3 pt-lg-0 my-auto d-flex justify-content-sm-end">

                <a href="<?php echo e(url('admin/order-export')); ?>"  class="btn btn-primary d-flex align-items-center ms-2">
                    <span class="d-none d-md-block">Export</span>

                </a>
                 <a href="<?php echo e(route('frontend.checkout', $cart->external_id.'#review')); ?>" target="_blank" class="btn btn-primary d-flex align-items-center ms-2">
                    <span class="d-none d-md-block">View Order </span>
                </a>

                <a href="<?php echo e(route('admin.order.index')); ?>" class="btn btn-primary d-flex align-items-center ms-2">

                    <span class="d-none d-md-block">View All Orders</span>
                </a>
            </div>
        </div>

        <div class="bg-white rounded page-height mt-3 shadow p-4">
            <div
                class="bg-primary p-2 rounded mb-3 text-white d-flex flex-wrap align-items-center justify-content-between">
                <p class="mb-0">
                    Order status: <?php echo e($status); ?>  <?php echo e(date("Y-m-d h.i A",strtotime($order->updated_at))); ?>

                   
                </p>
                <p class="mb-0">Order ID: <?php echo e($order->order_id); ?></p>
            </div>

            <div class="row">
                <div class="col-md-4 mb-3">
                    <h5>Shipping information</h5>
                    <?php echo $__env->make('admin.order.shipping', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                <div class="col-md-4 mb-3">
                    <h5>Billing information</h5>
                 <?php echo $__env->make('admin.order.billing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                <div class="col-md-4 mb-3">
                    <ul class="payment-history">
                        <li>
                            <p class="mb-2 me-3">Subtotal</p>
                            <p class="mb-2">$<span id="subtotal<?php echo e($order->id); ?>"><?php echo e(number_format($cart->cart_total_price,2)); ?></span></p>
                        </li>
                        <li>
                            <p class="mb-2 me-3">Sale Discount</p>
                            <p class="mb-2">-$<span id="discount"><?php echo e(number_format($totalSave,2)); ?></span></p>
                        </li>
                        <?php if(!empty($order->cart->coupon) && !empty($order->cart->discount)): ?>
                        <li>
                            <p class="mb-2 me-3">Coupon Discount <b>(<?php echo e($order->cart->coupon); ?>)</b></p>
                            <p class="mb-2">-$<?php echo e($helpers->withoutRounding($cart->cart_item_discount, 2)); ?> </p>
                        </li>
                        <?php endif; ?>
                        <li>
                            <p class="mb-0 me-3">Tax</p>
                            <p class="mb-0">+$<?php echo e($helpers->taxCalculation($order->cart_id)); ?></p>
                        </li>
                        <li>
                            <p class="mb-0 me-3">Shipping</p>
                            <p class="mb-0">+$<?php echo e(number_format($cart->shipping_extra_amount,2) ?? 0.00); ?></p>
                        </li>
                        <li>
                            <p class="mb-0 me-3">Handling</p>
                            <p class="mb-0">+$<?php echo e(number_format($cart->handling_extra_amount,2)?? 0.00); ?></p>
                        </li>
                    </ul>
                    <ul class="payment-history mb-0">
                        <li>
                            <p class="mb-2 me-3 fw-bold">Your Price:</p>
                            <p class="mb-2">$<span id="your_price"><?php echo e($helpers->grand_total_amount($cart->id)); ?></span></p>
                         
                        </li>
                    </ul>

                    <div>
                        <h5 class="mt-3">Order Status:</h5>
                      
                        <div class="check-box d-inline-block mb-2">
                            <input type="checkbox" id="email_status" name="email_status">
                            <label for="email_status">Send Email</label>
                        </div>
                         
                        <select class="form-select" aria-label="Default select example" id="order_status">
                            <?php $__currentLoopData = $orderStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($status->id); ?>" <?php echo e($order->order_status == $status->id ? 'selected' : ''); ?> ><?php echo e($status->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <input type="hidden" name="current" id="current" value="<?php echo e($order->order_status); ?>" />
                    </div>
                </div>
            </div>
            <div class="row pt-2">
                <form>
                    <div class="row">
                        <div class="col-sm-6 mb-3">
                            <h5>Customer note</h5>
                            <div class="shadow-sm p-3 mb-3 rounded customer_note_list">
                                <h6 class="text-secondary"><?php echo e($order->customer->customer_first_name ?? ''); ?></h6>
                                <hr class="my-2" />
                                <?php $__currentLoopData = $order->notes->where('receiver','customer'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cnote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="txt__sm mb-0">
                                    <?php echo e($cnote->note); ?>

                                </p>
                                <small>
                                    <?php echo e($cnote->created_at->diffForHumans()); ?>

                                </small>
                                <hr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <form method="post" action="">
                                <textarea class="form-control mb-3" rows="5" name="customer_note" id="customer_note"
                                    placeholder="Message"></textarea>
                                <input type="hidden" name="corder_id" id="corder_id" value="<?php echo e($order->id); ?>">
                                <select class="btn btn-primary" name="customer" id="customer">
                                    <option value="customer">Select Action</option>
                                    <option value="customer">Send to Customer</option>
                                    <option value="internally">Save it Internally</option>
                                </select>
                            </form>
                        </div>
                        <div class="col-sm-6 mb-3">
                            <h5>Vendor note</h5>
                            <div class="shadow-sm p-3 mb-3 rounded vendor_note_list">
                                <h6 class="text-secondary"><?php echo e(@$order->customer->customer_first_name); ?> NC</h6>
                                <hr class="my-2" />
                                <?php $__currentLoopData = $order->notes->where('receiver','vendor'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cnote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="txt__sm mb-0">
                                    <?php echo e($cnote->note); ?>

                                </p>
                                <small>
                                    <?php echo e($cnote->created_at->diffForHumans()); ?>

                                </small>
                                <hr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <form method="post" action="">
                                <textarea class="form-control mb-3" rows="5" name="vendor_note" id="vendor_note"
                                    placeholder="Message"></textarea>
                                <input type="hidden" name="vorder_id" id="vorder_id" value="<?php echo e($order->id); ?>">
                                <select class="btn btn-primary" name="vendor" id="vendor">
                                    <option value="">Select Action</option>
                                    <option value="vendor">Send to Vendor</option>
                                    <option value="internally">Save it Internally</option>
                                </select>
                            </form>
                        </div>
                    </div>
                </form>
            </div>
            <div class="row pt-4 align-items-center">
                <div class="col-sm-4 mb-3">
                    <h5 class="mb-0 d-flex"><p id="line_items"><?php echo e(count($order->orderEntries)); ?></p><p class="mx-1">LINE ITEMS</p></h5>
                </div>
                
            </div>

            <?php $__currentLoopData = $order->orderEntries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form method="post" action="<?php echo e(url('admin/update-order-entry')); ?>" id="form<?php echo e($item->id); ?>">
                    <div class="bg-ex-light rounded mb-3 p-3" id="entry_id<?php echo e($item->id); ?>">

                        <h5>
                            <?php echo e($item->product->name); ?>

                        </h5>
                        <hr />
                        <div class="row">

                            <div class="col-lg-8">
                                <div class="row">

                                    <?php

                                        $allOptions = $item->item($item->option_value);
                                        $canEdit = "editOptions";
                                        $disable = "customDisabledd";
                                        $days = $order->created_at->diffInDays(now());
                                        if( $days >= 1 ){
                                            $canEdit ="";
                                            $disable = "customDisabled";
                                        }

                                    ?>
                                    <?php $__currentLoopData = $item->item($item->option_value); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $allItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                                        <?php if($key !== "total_price" && $key !== "cart_id"  && $key !== "unit_price"  && $key !== "option_width_fraction" && $key !== "option_height_fraction" && $key!== "measurement_price"): ?>
                                            <div class="col-sm-6 entryItems<?php echo e($item->id); ?>  customDisabled">

                                                <?php if($key === "option_color"): ?>
                                                    <p class="mb-1 d-flex align-items-center"><b class="w-50 fw-semibold">Colour:</b>
                                                    <select class="form-select form-select-sm bg-transparent input-color w-50  activeColor input<?php echo e($item->id); ?> "  data-id="<?php echo e($item->id); ?>"  data-key="<?php echo e($key); ?>" name="<?php echo e($key); ?>">
                                                 
                                                            <?php $__currentLoopData = $item->product->colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($color->id); ?>" <?php echo e($color->id == $allItem['option_color'] ? 'selected' : ''); ?>><?php echo e($color->color->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                     <p class="mb-1 d-flex align-items-center"><b class="w-50 fw-semibold">Vendor Colour:</b>
                                                        
                                                         <input type="text" class="form-control w-50 form-control-sm bg-transparent input-color <?php echo e($canEdit); ?>  activeColor input<?php echo e($item->id); ?>"  data-id="<?php echo e($item->id); ?>" data-key="<?php echo e($key); ?>"  value="<?php echo e($helpers->vendorColorName($allItem['option_color'])); ?>" readonly/>
                                                     </p>

                                                <?php elseif($key === "option_width"): ?>
                                                    <div class="mb-1 d-flex align-items-center"><b class="w-50 fw-semibold">Width <small>(Inches)</small>:</b>

                                                    <span calss="row gx-2 w-50">
                                                        <span class="col-auto">

                                                    <select class="form-select form-select-sm bg-transparent input-color <?php echo e($canEdit); ?>   activeColor  input<?php echo e($item->id); ?>" style="width:75px"  data-id="<?php echo e($item->id); ?>"  data-key="<?php echo e($key); ?>" name="<?php echo e($key); ?>">
                                                        <?php for($i = 12; $i <= 130; $i++ ): ?>
                                                        <option value="<?php echo e($i); ?>" <?php echo e($allItem['option_width'] == $i ? 'selected' : ''); ?>><?php echo e($i); ?> </option>
                                                        <?php endfor; ?>
                                                    </select>
                                                </span>

                                                    <span class="col-auto">

                                                    <select class="form-select form-select-sm bg-transparent input-color <?php echo e($canEdit); ?>   activeColor input<?php echo e($item->id); ?>"  style="width:100px" data-id="<?php echo e($item->id); ?>"  data-key="option_width_fraction" name="option_width_fraction">

                                                        
                                                        <option <?php echo e(trim($allOptions['option_width_fraction']['option_width_fraction'] ?? '') == "0/0" ? 'selected' : ' '); ?>  value="0/0">0/0</option>
                                                        <option <?php echo e(trim($allOptions['option_width_fraction']['option_width_fraction']?? '') == "1/2" ? 'selected' : ' '); ?> value="1/2">1/2</option>
                                                        <option <?php echo e(trim($allOptions['option_width_fraction']['option_width_fraction'] ?? '') == "1/4" ? 'selected' : ' '); ?> value="1/4">1/4</option>
                                                        <option <?php echo e(trim($allOptions['option_width_fraction']['option_width_fraction'] ?? '') == "1/8" ?'selected' : ' '); ?> value="1/8">1/8</option>
                                                        <option <?php echo e(trim($allOptions['option_width_fraction']['option_width_fraction'] ?? '') == "3/4" ? 'selected' : ' '); ?> value="3/4">3/4 </option>
                                                        <option <?php echo e(trim($allOptions['option_width_fraction']['option_width_fraction'] ?? '') == "3/8" ? 'selected' : ' '); ?> value="3/8">3/8</option>
                                                        <option <?php echo e(trim($allOptions['option_width_fraction']['option_width_fraction'] ?? '') == "5/8" ? 'selected' : ' '); ?> value="5/8">5/8</option>
                                                        <option <?php echo e(trim($allOptions['option_width_fraction']['option_width_fraction'] ?? '') == "7/8" ? 'selected' : ' '); ?> value="7/8">7/8 </option>
                                                     
                                                    </select>
                                                </span>
                                                    </span>
                                                </div>

                                                <?php elseif($key === "option_height"): ?>
                                                    <p class="mb-1 d-flex align-items-center"><b class="w-50 fw-semibold">Height <small>(Inches)</small>:</b>
                                                        <small calss="d-flex">
                                                        <select class="form-select form-select-sm bg-transparent input-color <?php echo e($canEdit); ?>  activeColor input<?php echo e($item->id); ?>"  style="width:75px !important" data-id="<?php echo e($item->id); ?>"  data-key="<?php echo e($key); ?>" name="<?php echo e($key); ?>">
                                                            <?php for($i = 18; $i <= 150; $i++ ): ?>
                                                            <option value="<?php echo e($i); ?>" <?php echo e($allItem['option_height'] == $i ? 'selected' : ''); ?>><?php echo e($i); ?> </option>
                                                            <?php endfor; ?>
                                                        </select>

                                                        <select class="form-select form-select-sm bg-transparent input-color <?php echo e($canEdit); ?>   activeColor input<?php echo e($item->id); ?>"  style="width:100px !important"   data-id="<?php echo e($item->id); ?>"  data-key="option_height_fraction" name="option_height_fraction">
                                                            <option <?php echo e(trim($allOptions['option_height_fraction']['option_height_fraction'] ?? '') == "0/0" ? 'selected' :' '); ?> value="0/0">0/0</option>
                                                            <option <?php echo e(trim($allOptions['option_height_fraction']['option_height_fraction'] ?? '') == "1/2" ? 'selected' :' '); ?> value="1/2">1/2</option>
                                                            <option <?php echo e(trim($allOptions['option_height_fraction']['option_height_fraction']?? '') == "1/4"? 'selected' : ' '); ?> value="1/4">1/4</option>
                                                            <option <?php echo e(trim($allOptions['option_height_fraction']['option_height_fraction']??'') == "1/8" ? 'selected' :' '); ?> value="1/8">1/8</option>
                                                            <option <?php echo e(trim($allOptions['option_height_fraction']['option_height_fraction']??'') == "3/8" ? 'selected' : ' '); ?> value="3/8">3/8</option>
                                                            <option <?php echo e(trim($allOptions['option_height_fraction']['option_height_fraction']??'') == "3/4" ? 'selected': ''); ?> value="3/4"> 3/4 </option>
                                                            <option <?php echo e(trim($allOptions['option_height_fraction']['option_height_fraction']??'') == "5/8" ? 'selected': ' '); ?> value="5/8">5/8</option>
                                                            <option <?php echo e(trim($allOptions['option_height_fraction']['option_height_fraction']??'') == "7/8" ? 'selected' : ' '); ?> value="7/8">7/8 </option>
                                                        </select>

                                                    </small> 
                                                </p>
                                               
                                                <?php else: ?>
                                                    <p class="mb-1 d-flex align-items-center"><b class="w-50 fw-semibold"><?php echo e(ucwords(str_replace(['option_', '_'],["", " "], $key))); ?>:</b>
                                                    <input type="text" class="form-control w-50 form-control-sm bg-transparent input-color <?php echo e($canEdit); ?>  activeColor input<?php echo e($item->id); ?>"  data-id="<?php echo e($item->id); ?>" data-key="<?php echo e($key); ?>"  value="<?php echo e($item->optionName($allItem[$key], $key)); ?>" readonly/>

                                                    <!--for value change -->
                                                    <input type="hidden" class="form-control w-50 form-control-sm bg-transparent input-color" value="<?php echo e($allItem[$key]); ?>" name="<?php echo e($key); ?>"/>
                                                    
                                                </p>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </div>


                            <div class="col-lg-3">
                                <ul class="payment-history txt__sm">
                                    <li>
                                        <p class="mb-2 me-3 fw-semibold ">Qty</p>
                                        
                                                <p class="mb-2">
                                            <input type="number" class="form-control w-50 form-control-sm bg-transparent input-color <?php echo e($canEdit); ?> <?php echo e($disable); ?> entryItems<?php echo e($item->id); ?> input<?php echo e($item->id); ?>" data-id="<?php echo e($item->id); ?>" data-key="quantity"
                                                value="<?php echo e($item->quantity); ?>" name="quantity" readonly></p>
                                    </li>
                                    <li>
                                        <p class="mb-2 me-3 fw-semibold">Warranty</p>
                                        <p class="mb-2">7 Year Warranty</p>
                                    </li>

                                    <li>
                                        <p class="mb-2 me-3 fw-semibold">TOTAL</p>
                                        <p class="mb-2">$<span id="itemtotal<?php echo e($item->id); ?>"><?php echo e(number_format($item->purchase_price,2)); ?></span></p>
                                    </li>
                                </ul>
                            </div>

                           <?php if($order->order_status != 8): ?>

                            <div class="col-lg-1">

                                <div class="mb-2">
                                    <button class="btn btn-primary entryEdit" id="entryEdit<?php echo e($item->id); ?>" data-id="<?php echo e($item->id); ?>"  data-bs-toggle="tooltip" data-container="body" title="Edit">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                            class="bi bi-pencil-fill" viewBox="0 0 16 16">
                                            <path
                                                d="M12.854.146a.5.5 0 0 0-.707 0L10.5 1.793 14.207 5.5l1.647-1.646a.5.5 0 0 0 0-.708l-3-3zm.646 6.061L9.793 2.5 3.293 9H3.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.207l6.5-6.5zm-7.468 7.468A.5.5 0 0 1 6 13.5V13h-.5a.5.5 0 0 1-.5-.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.5-.5V10h-.5a.499.499 0 0 1-.175-.032l-.179.178a.5.5 0 0 0-.11.168l-2 5a.5.5 0 0 0 .65.65l5-2a.5.5 0 0 0 .168-.11l.178-.178z" />
                                        </svg>
                                    </button>
                                    <button class="btn btn-primary saveEntry entrySave" id="saveEntry<?php echo e($item->id); ?>" data-id="<?php echo e($item->id); ?>" type="submit" data-bs-toggle="tooltip" data-container="body" title="Edit">
                                        <img src="<?php echo e(url('fonts/save.png')); ?>">
                                    </button>
                                </div>
                                <div class="mb-2 delete_entry" data-id="<?php echo e($item->id); ?>" >
                                    <button type="button" class="btn btn-primary delete_item" data-bs-toggle="tooltip" data-container="body"
                                        id="delete_item<?php echo e($item->id); ?>" title="Delete">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                            class="bi bi-trash" viewBox="0 0 16 16">
                                            <path
                                                d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z" />
                                            <path fill-rule="evenodd"
                                                d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4L4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z" />
                                        </svg>
                                    </button>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php if(!empty($item->customer_note)): ?>
                              <div class="col-lg-2">
                                <ul class="payment-history txt__sm">
                                    <li class="d-flex">
                                        <p class="mb-2 me-3">Note:</p>
                                        <p class="mb-2"><?php echo e($item->customer_note); ?></p>
                                    </li>
                                </ul>
                            </div>
                            <?php endif; ?>
                            <?php if(!empty($item->room_name )): ?>
                            <div class="col-lg-2">
                                <ul class="payment-history txt__sm">
                              
                                    <li class="d-flex">
                                        <p class="mb-2 me-3 ">Room Name:</p>
                                        <p class="mb-2"><?php echo e($item->room_name); ?></p>
                                    </li>
                                </ul>
                            </div>
                            <?php endif; ?>


                        </div>

                    </div>
                </form>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>

</section>




<script>
    $(document).ready( function($) {
        host = "<?php echo e(url('admin/note')); ?>";

        $("#vendor").on("change",function(e){
            e.preventDefault();
            var note = $('#vendor_note').val();
            var order_id = $('#vorder_id').val();
            var receiver = "vendor";
            var action = $('#vendor').val();
            $("#alert_message").text("Are you sure?");
            $("#exampleModaltwo").modal('show');
            $("#model-yes").on("click",function(x){

                $("#exampleModaltwo").modal('hide');

                if(note != ""){
                    $.ajax({
                        type: "POST",
                        url: host,
                        data: {note:note, order_id:order_id, receiver:receiver},
                        success: function( msg ) {
                            if(msg.status){
                                $(".vendor_note_list").append("<p class='txt__sm mb-0'>"+note+"</p><small>0 seconds ago </small><hr/>");
                                $("#vendor_note").val("");
                                $(".vendor_note_list").scrollTop($(".vendor_note_list")[0].scrollHeight);
                            }
                        }
                    });
                }
            });
       });

        $("#customer").on("change",function(e){
            e.preventDefault();
            var note = $('#customer_note').val();
            var order_id = $('#corder_id').val();
            var receiver = "customer";
            var action = $('#customer').val();
            $("#alert_message").text("Are you sure?");
            $("#exampleModaltwo").modal('show');
            $("#model-yes").on("click",function(x){

                $("#exampleModaltwo").modal('hide');
                if(note != ""){
                    $.ajax({
                        type: "POST",
                        url: host,
                        data: {note:note, order_id:order_id, receiver:receiver},
                        success: function( msg ) {
                            if(msg.status){
                                $(".customer_note_list").append("<p class='txt__sm mb-0'>"+note+"</p><small>0 seconds ago </small><hr/>");
                                $("#customer_note").val("");
                                $(".customer_note_list").scrollTop($(".customer_note_list")[0].scrollHeight);
                            }
                        }
                    });
                }
            });
       });

        var currentStatus = $('#order_status').val();
        var newStatus = '';
        var order_id = "<?php echo e($order->id); ?>";
        $("#order_status").on("change", function(e){
            newStatus = $(this).val();
            $(this).val(currentStatus);
            $('#tracking-append-fild').empty();
            e.preventDefault();
            $("#alert_message").html(`Are you sure want to change the status?
            <div class="text-start pt-3">
                <label class="pb-2 mt-2 small">Tracking Number</label>
                <div class="row gx-2 mb-2 abc">
                    <div class="col-12">
                        <input type="text" class="form-control order_tracking_number" name="order_tracking_number[]"  value="">
                    </div>
                    <!-- <div class="col-3 d-flex text-end">
                        <button type="button" class="btn btn-sm btn-primary add-tracking-number">+</button>
                    </div> -->
                </div>
                <div id="tracking-append-fild"></div>
             </div>`);

             $(document).on('click', '.add-tracking-number', function (e) {
                 e.preventDefault();
                $('#tracking-append-fild').append(`
                <div class="row gx-2 remove mb-2 pe-2">
                    <div class="col-9">
                        <input type="text" class="form-control order_tracking_number" name="order_tracking_number[]" value="">
                    </div>
                    <div class="col-3 d-flex text-end">
                        <button type="button" class="btn btn-sm me-1 btn-primary remove-tracking-number btn-secondary">-</button>
                        <button type="button" class="btn btn-sm btn-primary add-tracking-number">+</button>
                    </div>
                </div>`);

                $("#tracking-append-fild").stop().animate({ scrollTop: $("#tracking-append-fild")[0].scrollHeight }, 1000);

             });

            $(document).on('click', '.remove-tracking-number', function (e) {
                $(this).parents('.remove').remove();
                e.preventDefault();
            });

            $("#exampleModaltwo").modal('show');
            
       });
        $(document).on("click", "#model-no",function(e){
            $('#order_status').val(currentStatus);
        });
        $(document).on("click", "#model-yes",function(e){
            var email_status = $("#email_status").is(":checked");
            var trackingNumber = $(document).find("input[name='order_tracking_number[]']").map(function(){
                return $(this).val();
            }).get();

            if(newStatus == 7 ){
                if(trackingNumber == '' ){
                    toastr.error("Please Enter The Tracking Number");
                    $("#exampleModaltwo").modal('show');
                }
            }

            $("#exampleModaltwo").modal('hide');
            axios.post('/admin/change-order-status',{
                'status': newStatus, 
                'order_id': order_id,
                'trackingNumber': trackingNumber,
                'is_email_active': email_status
            }).then((response)=>{
                if(response.data.status == true){
                    $("#order_status").val(newStatus);
                }
            })
        });


       deleteEntry = "<?php echo e(url('admin/delete-order-entry')); ?>";

        $(".delete_entry").on("click",function(e){
            e.preventDefault();
            var entry_id = $(this).data("id");
            var order_id = "<?php echo e($order->id); ?>";

            item_count = $("#line_items").text();

            $("#alert_message").text("Are you sure want to delete the item?");
            $("#exampleModaltwo").modal('show');
            $("#model-yes").on("click",function(x){

                $("#exampleModaltwo").modal('hide');
                $.ajax({
                    type: "POST",
                    url: deleteEntry,
                    data: {order_id:order_id, entry_id:entry_id},
                    success: function( msg ) {
                        console.log(msg);
                        // $("#entry_id"+entry_id).css('display','none');
                        if(msg.status){
                            $("#entry_id"+entry_id).css('display','none');
                            item_count = item_count - 1;
                            $("#line_items").text(item_count);
                            // $(".customer_note_list").append("<p class='txt__sm mb-0'>"+note+"</p><small>0 seconds ago </small><hr/>");
                            // $("#customer_note").val("");
                            // $(".customer_note_list").scrollTop($(".customer_note_list")[0].scrollHeight);
                        }
                    }
                });
            });
       });


       // $(document).on("click", ".input-color", function (e) {
       //      var current = $(this);
       //      console.log(current);
       //      current.removeAttr('readonly').addClass('border_color');
       // });


        $(document).on('click', function (e) {
            if (!$(e.target).is('.table-input')) {
                var inputclick = $(".table-input");

                $.each(inputclick, function () {
                    var $this = $(this);
                    if ($this.hasClass('border_color')) {
                        $this.removeClass('border_color');
                        $this.attr('readonly', 'readonly');
                    }
                });
            }
        });

        $(".entryEdit").on("click",function(e){
            //console.log("edit entry click");
            e.preventDefault();
            // console.log("ok");
            var entry_id = $(this).data("id");
             console.log(entry_id);
            $("#entryEdit"+entry_id).css("display","none");
            $("#saveEntry"+entry_id).css("display","block");
            $(".entryItems"+entry_id).removeClass('customDisabled');
            $(".input"+entry_id).removeAttr("readonly");

            $(".input"+entry_id).removeClass('activeColor')
        });


        var updateUrl = "<?php echo e(url('admin/update-order-entry')); ?>";

        $(".saveEntry").on("click",function(e){
            e.preventDefault();

            var entry_id = $(this).data("id");

            order_id =  "<?php echo e($order->id); ?>";

            var request = $.ajax({
                url: updateUrl,
                method: "POST",
                data: $('#form'+entry_id).serialize(),
            });
            request.done(function( res ) {
             
                // $this.val(newcont);
                $("#entryEdit"+entry_id).css("display","block");
                $("#saveEntry"+entry_id).css("display","none");

                $(".entryItems"+entry_id).addClass('customDisabled');
                $(".input"+entry_id).addClass('activeColor');
                $(".input"+entry_id).attr("readonly",'true');
                $("#itemtotal"+entry_id).text(res.item);
                $("#subtotal"+order_id).text(res.subTotal);
                $("#your_price").text(res.total);
                $("#discount").text(res.totalDiscount);
                toastr.success("Details Saved Successfully");
            });
            request.fail(function( jqXHR, textStatus ) {
              //  alert( "Request failed: " + textStatus );
            });



        });

    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Backend.admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\heyblinds\resources\views/admin/order/show.blade.php ENDPATH**/ ?>