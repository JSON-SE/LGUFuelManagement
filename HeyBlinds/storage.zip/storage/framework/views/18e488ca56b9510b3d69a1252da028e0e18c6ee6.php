<!DOCTYPE html>
<html lang="en">
<?php
use App\Models\Admin\Product\Product;
?>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sample Orders Inventory Report</title>
</head>
<body>
    <table>
        <tr>
            <td><h4>HB Color # (AKA HB Location #)</h4></td>
            <td><h4>Active/Inactive</h4></td>
            <td><h4>HB Product Name</h4></td>
            <td><h4>HB Color Name</h4></td>
            <td><h4>Vendor Color Name</h4></td>
            <td><h4>Qty remaining</h4></td>
        </tr>
    <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $color->productColor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $quantity =  $color->quantity - $color->quantity($color->id) ?? 0;
        ?>
        <tr>
            <td><?php echo e($color->color_id); ?> </td>
            <td><?php echo e(($color->is_enable == 1 ) ? "Active" : "Inactive"); ?> </td>
            <td><?php echo e($product->product->name); ?> </td>
            <td><?php echo e($color->name); ?> </td>
            <td><?php echo e($color->vendor_color_name); ?> </td>
            <td><?php echo e($quantity > 0 ? $quantity : 0); ?> </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html>
<?php /**PATH D:\Project\heyblinds\resources\views/exports/sample-orders-inventory.blade.php ENDPATH**/ ?>